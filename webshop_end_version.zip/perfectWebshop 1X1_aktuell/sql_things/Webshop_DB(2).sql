-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 11. Jun 2024 um 16:03
-- Server-Version: 10.4.21-MariaDB
-- PHP-Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `Webshop_DB`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `kunden`
--

CREATE TABLE `kunden` (
  `KundenID` varchar(320) NOT NULL,
  `generiertesPW` varchar(100) DEFAULT NULL,
  `Vorname` text DEFAULT NULL,
  `Nachname` text DEFAULT NULL,
  `DatumVergangen` varchar(100) DEFAULT NULL,
  `WochentagVergangen` varchar(100) DEFAULT NULL,
  `aufloesung` varchar(100) DEFAULT NULL,
  `GoogleOAuth` varchar(100) DEFAULT NULL,
  `DatumJetzt` date DEFAULT NULL,
  `WochentagJetzt` varchar(30) DEFAULT NULL,
  `BenutzerPW` varchar(560) DEFAULT NULL,
  `betriebssystem` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `kunden`
--

INSERT INTO `kunden` (`KundenID`, `generiertesPW`, `Vorname`, `Nachname`, `DatumVergangen`, `WochentagVergangen`, `aufloesung`, `GoogleOAuth`, `DatumJetzt`, `WochentagJetzt`, `BenutzerPW`, `betriebssystem`) VALUES
('elias.maurer@student.reutlingen-university.de', 'xkAud9', 'elias', 'maurer', '2024-06-11', 'Tuesday', 'Macos', 'I5XG23I24M73BQ4H', '2024-06-11', 'Tuesday', '$2y$10$ZRSYNZleL97v4WKhDM5K3OAIS.RZjdkmK01JsKEjc7rX/ZiQMx5Oq', NULL),
('elias_maurer@gmx.net', '$2y$10$B4d.ewRVWPAV83zXwahSWOC3YauEywHGSRVGt5uPIJGuBVr5y8cvu', 'elias', 'maurer', '2024-06-11', 'Tuesday', '967x1920', '62HDPSZBB3FV54FI', '2024-06-11', 'Tuesday', '$2y$10$AYfh5ulhyW6i5DIYLvKU.Oef8mPk6VIdsclh28CavgjNFR5JAFIiq', 'Macos'),
('paul.mattheus@gmx.de', '$2y$10$Gry/YCASl2nLD4e4eg5mzOvRGiAgHxBYe.rpj0ULGI9ou3fwA32Jy', 'Paul', 'Mattheus', '2024-06-02', 'Sunday', '807x931', 'OL44MLRDHRKNJIHC', '2024-06-02', 'Sunday', '$2y$10$tCyMVlkLJYT8wJEv4l63HOV9F3nBo26J8foQXEOuTVRxAJbZDfNFW', 'Macos');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `logs`
--

CREATE TABLE `logs` (
  `Benutzername` varchar(320) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `produkte`
--

CREATE TABLE `produkte` (
  `ProduktID` int(11) NOT NULL,
  `ProduktName` varchar(100) DEFAULT NULL,
  `Preis` decimal(10,2) DEFAULT NULL,
  `Beschreibung` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `produkte`
--

INSERT INTO `produkte` (`ProduktID`, `ProduktName`, `Preis`, `Beschreibung`) VALUES
(551, 'AGV PISTA GP', '1399.99', 'Premium Helm'),
(552, 'easybike PRO+', '700.00', 'Pro Helm, welcher zu deinen Beduerfnissen passt'),
(553, 'Aeasybike F2', '299.99', 'Budget Helm, welcher ideal zu dir zugeschnitten ist'),
(561, 'GP Jacket', '1450.00', 'Premium Jacket, für deine Rennader'),
(562, 'Jacket PRO+', '1000.00', 'Pro Jacket, um dich immer zu schützen'),
(563, 'Jacket Ü4', '700.00', 'Unsere Buget Option, um dich rund um zu schützen'),
(571, 'GP Glove', '450.00', 'Premium Handschuhe, für deine Rennsport Gelüste'),
(572, 'Glove PRO+', '250.50', 'Pro Handschuhe'),
(573, 'Glove p3', '99.99', 'Budget Handschuhe');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `punkte`
--

CREATE TABLE `punkte` (
  `BenutzernameID` varchar(320) NOT NULL,
  `punkte` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `punkte`
--

INSERT INTO `punkte` (`BenutzernameID`, `punkte`) VALUES
('elias.maurer@student.reutlingen-university.de', 8),
('elias_maurer@gmx.net', 35),
('paul.mattheus@gmx.de', 29);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `rechnungskopf`
--

CREATE TABLE `rechnungskopf` (
  `rechnungskopf_id` int(11) NOT NULL,
  `kunden_id` varchar(50) NOT NULL,
  `rechnungskopf_date` date DEFAULT NULL,
  `summe` decimal(10,2) DEFAULT NULL,
  `versandart` varchar(50) DEFAULT NULL,
  `bezahlungsart` varchar(50) DEFAULT NULL,
  `kundenVorname` varchar(255) DEFAULT NULL,
  `kundenNachname` varchar(255) DEFAULT NULL,
  `kundenBundesstaat` varchar(30) DEFAULT NULL,
  `zipcode` varchar(10) DEFAULT NULL,
  `username` varchar(60) DEFAULT NULL,
  `strasse` varchar(100) DEFAULT NULL,
  `stadt` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `rechnungskopf`
--

INSERT INTO `rechnungskopf` (`rechnungskopf_id`, `kunden_id`, `rechnungskopf_date`, `summe`, `versandart`, `bezahlungsart`, `kundenVorname`, `kundenNachname`, `kundenBundesstaat`, `zipcode`, `username`, `strasse`, `stadt`) VALUES
(1, '562', '2024-05-28', '7599.97', 'standard', 'on', 'elias', 'maurer', 'Baden-Württemberg', '72770', NULL, NULL, NULL),
(2, '562', '2024-05-28', '7599.97', 'standard', 'on', 'elias', 'maurer', 'Baden-Württemberg', '72770', NULL, NULL, NULL),
(3, '562', '2024-05-28', '7599.97', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', NULL, NULL, NULL),
(4, '562', '2024-05-28', '7599.97', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(5, '562', '2024-05-28', '7599.97', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(6, '562', '2024-05-28', '7599.97', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(7, '552', '2024-05-28', '2099.99', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(8, '552', '2024-05-28', '2099.99', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(9, '552', '2024-05-28', '2099.99', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(10, '552', '2024-05-28', '2099.99', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(11, '562', '2024-05-28', '3099.99', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(12, '562', '2024-05-28', '3099.99', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(13, '562', '2024-05-28', '3103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(14, '562', '2024-05-28', '3103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(15, '562', '2024-05-28', '3103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(16, '562', '2024-05-28', '3103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(17, '562', '2024-05-28', '3103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(18, '562', '2024-05-28', '3103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(19, '562', '2024-05-28', '3103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(20, '562', '2024-05-28', '3103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(21, '562', '2024-05-28', '3103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(22, '562', '2024-05-28', '3103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(23, '562', '2024-05-28', '3103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(24, '562', '2024-05-28', '3103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(25, '562', '2024-05-28', '3103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(26, '562', '2024-05-28', '3103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(27, '562', '2024-05-28', '3103.11', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(28, '562', '2024-05-28', '3103.09', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(29, '562', '2024-05-28', '3113.07', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(30, '562', '2024-05-28', '3113.05', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(31, '562', '2024-05-28', '3113.02', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(32, '562', '2024-05-28', '3113.00', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(33, '562', '2024-05-28', '3102.96', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(34, '561', '2024-05-28', '3557.94', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(35, '561', '2024-05-28', '3562.92', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(36, '561', '2024-05-28', '3557.89', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(37, '561', '2024-05-28', '3562.87', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(38, '561', '2024-05-28', '3562.85', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(39, '561', '2024-05-28', '3562.82', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(40, '561', '2024-05-28', '3562.80', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(41, '561', '2024-05-28', '3562.77', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(42, '561', '2024-05-28', '3557.74', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(43, '561', '2024-05-28', '3562.72', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(44, '561', '2024-05-28', '3557.69', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(45, '561', '2024-05-28', '3562.67', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(46, '561', '2024-05-28', '3557.64', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(47, '561', '2024-05-28', '3562.62', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(48, '561', '2024-05-28', '3557.59', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(49, '561', '2024-05-28', '3562.57', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(50, '561', '2024-05-28', '3557.54', 'express', '', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(51, '561', '2024-05-28', '3557.51', 'express', '', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(52, '561', '2024-05-28', '3557.49', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(53, '561', '2024-05-28', '3562.47', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(54, '561', '2024-05-28', '3562.45', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(55, '561', '2024-05-28', '3562.42', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(56, '561', '2024-05-28', '3562.40', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(57, '561', '2024-05-28', '3557.36', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(58, '561', '2024-05-28', '3557.34', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(59, '561', '2024-05-28', '3562.32', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(60, '561', '2024-05-28', '3557.29', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(61, '561', '2024-05-28', '3562.27', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(62, '571', '2024-05-28', '1902.25', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(63, '571', '2024-05-28', '1912.23', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(64, '571', '2024-05-28', '1912.21', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(65, '571', '2024-05-28', '1902.17', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(66, '571', '2024-05-28', '1912.16', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(67, '571', '2024-05-28', '1902.12', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(68, '571', '2024-05-28', '1902.10', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(69, '571', '2024-05-28', '1912.08', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(70, '571', '2024-05-28', '1914.00', '', 'Paypal', '', '', '', '', 'elias_maurer@gmx.net', NULL, NULL),
(71, '571', '2024-05-28', '1903.99', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(72, '571', '2024-05-28', '1903.99', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(73, '571', '2024-05-28', '1903.99', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(74, '571', '2024-05-28', '1903.99', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(75, '571', '2024-05-28', '1903.99', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(76, '552', '2024-05-29', '2103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(77, '90', '2024-05-30', '5208.97', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(78, '90', '2024-05-30', '5208.97', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(79, '90', '2024-05-30', '5208.97', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(80, '90', '2024-05-30', '5208.97', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(81, '90', '2024-05-30', '5208.97', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(82, '90', '2024-05-30', '5208.97', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(83, '91', '2024-05-30', '5208.97', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(84, '91', '2024-05-30', '5208.97', 'express', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(85, '92', '2024-05-30', '3563.99', 'overnight', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(86, '92', '2024-05-30', '3563.99', 'overnight', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(87, '92', '2024-05-30', '3563.99', 'overnight', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(88, '92', '2024-05-30', '3563.99', 'overnight', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(89, '92', '2024-05-30', '3563.99', 'overnight', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(90, '93', '2024-05-30', '1408.98', 'express', 'Paypal', 'eli', 'mau', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(91, '93', '2024-05-30', '1408.98', 'express', 'Paypal', 'eli', 'mau', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', NULL, NULL),
(92, '94', '2024-05-30', '3113.99', 'overnight', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', 'Kirchäckerweg 4', 'Reutlingen'),
(93, '94', '2024-05-30', '3113.99', 'overnight', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', 'Kirchäckerweg 4', 'Reutlingen'),
(96, '96', '2024-06-02', '3558.98', 'express', 'Paypal', 'Paul', 'Mattheus', 'Baden-Württemberg', '12345', 'paul.mattheus@gmx.de', 'XD Straße 123', 'Reutlingen'),
(97, '97', '2024-06-11', '2103.98', 'standard', 'Paypal', 'elias', 'maurer', 'Baden-Württemberg', '72770', 'elias_maurer@gmx.net', 'Kirchäckerweg 4', 'Reutlingen');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `rechnungsposition`
--

CREATE TABLE `rechnungsposition` (
  `line_item_id` int(11) NOT NULL,
  `rechnungskopf_id` int(11) NOT NULL,
  `produkt_id` int(11) NOT NULL,
  `menge` int(11) DEFAULT NULL,
  `preis` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `rechnungsposition`
--

INSERT INTO `rechnungsposition` (`line_item_id`, `rechnungskopf_id`, `produkt_id`, `menge`, `preis`) VALUES
(1, 7, 551, 1, '1399.99'),
(2, 8, 551, 1, '1399.99'),
(3, 9, 551, 1, '1399.99'),
(4, 9, 552, 1, '700.00'),
(5, 10, 551, 1, '1399.99'),
(6, 10, 552, 1, '700.00'),
(7, 11, 551, 1, '1399.99'),
(8, 11, 552, 1, '700.00'),
(9, 11, 562, 1, '1000.00'),
(10, 12, 551, 1, '1399.99'),
(11, 12, 552, 1, '700.00'),
(12, 12, 562, 1, '1000.00'),
(13, 13, 551, 1, '1399.99'),
(14, 13, 552, 1, '700.00'),
(15, 13, 562, 1, '1000.00'),
(16, 14, 551, 1, '1399.99'),
(17, 14, 552, 1, '700.00'),
(18, 14, 562, 1, '1000.00'),
(19, 15, 551, 1, '1399.99'),
(20, 15, 552, 1, '700.00'),
(21, 15, 562, 1, '1000.00'),
(22, 16, 551, 1, '1399.99'),
(23, 16, 552, 1, '700.00'),
(24, 16, 562, 1, '1000.00'),
(25, 17, 551, 1, '1399.99'),
(26, 17, 552, 1, '700.00'),
(27, 17, 562, 1, '1000.00'),
(28, 18, 551, 1, '1399.99'),
(29, 18, 552, 1, '700.00'),
(30, 18, 562, 1, '1000.00'),
(31, 19, 551, 1, '1399.99'),
(32, 19, 552, 1, '700.00'),
(33, 19, 562, 1, '1000.00'),
(34, 20, 551, 1, '1399.99'),
(35, 20, 552, 1, '700.00'),
(36, 20, 562, 1, '1000.00'),
(37, 21, 551, 1, '1399.99'),
(38, 21, 552, 1, '700.00'),
(39, 21, 562, 1, '1000.00'),
(40, 22, 551, 1, '1399.99'),
(41, 22, 552, 1, '700.00'),
(42, 22, 562, 1, '1000.00'),
(43, 23, 551, 1, '1399.99'),
(44, 23, 552, 1, '700.00'),
(45, 23, 562, 1, '1000.00'),
(46, 24, 551, 1, '1399.99'),
(47, 24, 552, 1, '700.00'),
(48, 24, 562, 1, '1000.00'),
(49, 25, 551, 1, '1399.99'),
(50, 25, 552, 1, '700.00'),
(51, 25, 562, 1, '1000.00'),
(52, 26, 551, 1, '1399.99'),
(53, 26, 552, 1, '700.00'),
(54, 26, 562, 1, '1000.00'),
(55, 27, 551, 1, '1399.99'),
(56, 27, 552, 1, '700.00'),
(57, 27, 562, 1, '1000.00'),
(58, 28, 551, 1, '1399.99'),
(59, 28, 552, 1, '700.00'),
(60, 28, 562, 1, '1000.00'),
(61, 29, 551, 1, '1399.99'),
(62, 29, 552, 1, '700.00'),
(63, 29, 562, 1, '1000.00'),
(64, 30, 551, 1, '1399.99'),
(65, 30, 552, 1, '700.00'),
(66, 30, 562, 1, '1000.00'),
(67, 31, 551, 1, '1399.99'),
(68, 31, 552, 1, '700.00'),
(69, 31, 562, 1, '1000.00'),
(70, 32, 551, 1, '1399.99'),
(71, 32, 552, 1, '700.00'),
(72, 32, 562, 1, '1000.00'),
(73, 33, 551, 1, '1399.99'),
(74, 33, 552, 1, '700.00'),
(75, 33, 562, 1, '1000.00'),
(76, 34, 551, 1, '1399.99'),
(77, 34, 552, 1, '700.00'),
(78, 34, 561, 1, '1450.00'),
(79, 35, 551, 1, '1399.99'),
(80, 35, 552, 1, '700.00'),
(81, 35, 561, 1, '1450.00'),
(82, 36, 551, 1, '1399.99'),
(83, 36, 552, 1, '700.00'),
(84, 36, 561, 1, '1450.00'),
(85, 37, 551, 1, '1399.99'),
(86, 37, 552, 1, '700.00'),
(87, 37, 561, 1, '1450.00'),
(88, 38, 551, 1, '1399.99'),
(89, 38, 552, 1, '700.00'),
(90, 38, 561, 1, '1450.00'),
(91, 39, 551, 1, '1399.99'),
(92, 39, 552, 1, '700.00'),
(93, 39, 561, 1, '1450.00'),
(94, 40, 551, 1, '1399.99'),
(95, 40, 552, 1, '700.00'),
(96, 40, 561, 1, '1450.00'),
(97, 41, 551, 1, '1399.99'),
(98, 41, 552, 1, '700.00'),
(99, 41, 561, 1, '1450.00'),
(100, 42, 551, 1, '1399.99'),
(101, 42, 552, 1, '700.00'),
(102, 42, 561, 1, '1450.00'),
(103, 43, 551, 1, '1399.99'),
(104, 43, 552, 1, '700.00'),
(105, 43, 561, 1, '1450.00'),
(106, 44, 551, 1, '1399.99'),
(107, 44, 552, 1, '700.00'),
(108, 44, 561, 1, '1450.00'),
(109, 45, 551, 1, '1399.99'),
(110, 45, 552, 1, '700.00'),
(111, 45, 561, 1, '1450.00'),
(112, 46, 551, 1, '1399.99'),
(113, 46, 552, 1, '700.00'),
(114, 46, 561, 1, '1450.00'),
(115, 47, 551, 1, '1399.99'),
(116, 47, 552, 1, '700.00'),
(117, 47, 561, 1, '1450.00'),
(118, 48, 551, 1, '1399.99'),
(119, 48, 552, 1, '700.00'),
(120, 48, 561, 1, '1450.00'),
(121, 49, 551, 1, '1399.99'),
(122, 49, 552, 1, '700.00'),
(123, 49, 561, 1, '1450.00'),
(124, 50, 551, 1, '1399.99'),
(125, 50, 552, 1, '700.00'),
(126, 50, 561, 1, '1450.00'),
(127, 51, 551, 1, '1399.99'),
(128, 51, 552, 1, '700.00'),
(129, 51, 561, 1, '1450.00'),
(130, 52, 551, 1, '1399.99'),
(131, 52, 552, 1, '700.00'),
(132, 52, 561, 1, '1450.00'),
(133, 53, 551, 1, '1399.99'),
(134, 53, 552, 1, '700.00'),
(135, 53, 561, 1, '1450.00'),
(136, 54, 551, 1, '1399.99'),
(137, 54, 552, 1, '700.00'),
(138, 54, 561, 1, '1450.00'),
(139, 55, 551, 1, '1399.99'),
(140, 55, 552, 1, '700.00'),
(141, 55, 561, 1, '1450.00'),
(142, 56, 551, 1, '1399.99'),
(143, 56, 552, 1, '700.00'),
(144, 56, 561, 1, '1450.00'),
(145, 57, 551, 1, '1399.99'),
(146, 57, 552, 1, '700.00'),
(147, 57, 561, 1, '1450.00'),
(148, 58, 551, 1, '1399.99'),
(149, 58, 552, 1, '700.00'),
(150, 58, 561, 1, '1450.00'),
(151, 59, 551, 1, '1399.99'),
(152, 59, 552, 1, '700.00'),
(153, 59, 561, 1, '1450.00'),
(154, 60, 551, 1, '1399.99'),
(155, 60, 552, 1, '700.00'),
(156, 60, 561, 1, '1450.00'),
(157, 61, 551, 1, '1399.99'),
(158, 61, 552, 1, '700.00'),
(159, 61, 561, 1, '1450.00'),
(160, 62, 561, 1, '1450.00'),
(161, 62, 571, 1, '450.00'),
(162, 63, 561, 1, '1450.00'),
(163, 63, 571, 1, '450.00'),
(164, 64, 561, 1, '1450.00'),
(165, 64, 571, 1, '450.00'),
(166, 65, 561, 1, '1450.00'),
(167, 65, 571, 1, '450.00'),
(168, 66, 561, 1, '1450.00'),
(169, 66, 571, 1, '450.00'),
(170, 67, 561, 1, '1450.00'),
(171, 67, 571, 1, '450.00'),
(172, 68, 561, 1, '1450.00'),
(173, 68, 571, 1, '450.00'),
(174, 69, 561, 1, '1450.00'),
(175, 69, 571, 1, '450.00'),
(176, 70, 561, 1, '1450.00'),
(177, 70, 571, 1, '450.00'),
(178, 71, 561, 1, '1450.00'),
(179, 71, 571, 1, '450.00'),
(180, 72, 561, 1, '1450.00'),
(181, 72, 571, 1, '450.00'),
(182, 73, 561, 1, '1450.00'),
(183, 73, 571, 1, '450.00'),
(184, 74, 561, 1, '1450.00'),
(185, 74, 571, 1, '450.00'),
(186, 75, 561, 1, '1450.00'),
(187, 75, 571, 1, '450.00'),
(188, 76, 551, 1, '1399.99'),
(189, 76, 552, 1, '700.00'),
(190, 78, 551, 2, '1399.99'),
(191, 78, 552, 2, '700.00'),
(192, 78, 562, 1, '1000.00'),
(193, 90, 551, 2, '1399.99'),
(194, 90, 552, 2, '700.00'),
(195, 90, 562, 1, '1000.00'),
(196, 90, 551, 2, '1399.99'),
(197, 90, 552, 2, '700.00'),
(198, 90, 562, 1, '1000.00'),
(199, 90, 551, 2, '1399.99'),
(200, 90, 552, 2, '700.00'),
(201, 90, 562, 1, '1000.00'),
(202, 90, 551, 2, '1399.99'),
(203, 90, 552, 2, '700.00'),
(204, 90, 562, 1, '1000.00'),
(205, 91, 551, 2, '1399.99'),
(206, 91, 552, 2, '700.00'),
(207, 91, 562, 1, '1000.00'),
(208, 91, 551, 2, '1399.99'),
(209, 91, 552, 2, '700.00'),
(210, 91, 562, 1, '1000.00'),
(211, 92, 551, 1, '1399.99'),
(212, 92, 561, 1, '1450.00'),
(213, 92, 563, 1, '700.00'),
(214, 92, 551, 1, '1399.99'),
(215, 92, 561, 1, '1450.00'),
(216, 92, 563, 1, '700.00'),
(217, 92, 551, 1, '1399.99'),
(218, 92, 561, 1, '1450.00'),
(219, 92, 563, 1, '700.00'),
(220, 92, 551, 1, '1399.99'),
(221, 92, 561, 1, '1450.00'),
(222, 92, 563, 1, '700.00'),
(223, 92, 551, 1, '1399.99'),
(224, 92, 561, 1, '1450.00'),
(225, 92, 563, 1, '700.00'),
(226, 93, 551, 1, '1399.99'),
(227, 93, 551, 1, '1399.99'),
(228, 94, 551, 1, '1399.99'),
(229, 94, 552, 1, '700.00'),
(230, 94, 562, 1, '1000.00'),
(231, 94, 551, 1, '1399.99'),
(232, 94, 552, 1, '700.00'),
(233, 94, 562, 1, '1000.00'),
(234, 95, 551, 1, '1399.99'),
(235, 95, 552, 1, '700.00'),
(236, 95, 561, 3, '1450.00'),
(237, 95, 551, 1, '1399.99'),
(238, 95, 552, 1, '700.00'),
(239, 95, 561, 3, '1450.00'),
(240, 96, 551, 1, '1399.99'),
(241, 96, 552, 1, '700.00'),
(242, 96, 561, 1, '1450.00'),
(243, 97, 551, 1, '1399.99'),
(244, 97, 552, 1, '700.00');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `testtable`
--

CREATE TABLE `testtable` (
  `warenkorbposition_id` int(11) NOT NULL,
  `menge` int(11) DEFAULT NULL,
  `preis` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `testtable`
--

INSERT INTO `testtable` (`warenkorbposition_id`, `menge`, `preis`) VALUES
(1, 1, '1399.99'),
(2, 1, '700.00');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `warenkorbkopf`
--

CREATE TABLE `warenkorbkopf` (
  `warenkorb_id` int(11) NOT NULL,
  `username_fk` varchar(320) DEFAULT NULL,
  `datumDerErstellung` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `warenkorbkopf`
--

INSERT INTO `warenkorbkopf` (`warenkorb_id`, `username_fk`, `datumDerErstellung`, `status`) VALUES
(3, 'elias_maurer@gmx.net', '2024-05-24 13:48:46', 'in Auftrag'),
(4, 'elias_maurer@gmx.net', '2024-05-24 13:50:39', 'in Auftrag'),
(5, 'elias_maurer@gmx.net', '2024-05-24 14:09:06', 'in Auftrag'),
(6, 'elias_maurer@gmx.net', '2024-05-24 14:44:49', 'in Auftrag'),
(7, 'elias_maurer@gmx.net', '2024-05-24 14:45:41', 'in Auftrag'),
(8, 'elias_maurer@gmx.net', '2024-05-24 14:47:07', 'in Auftrag'),
(9, 'elias_maurer@gmx.net', '2024-05-24 14:47:41', 'in Auftrag'),
(10, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 14:50:39', 'in Auftrag'),
(11, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 14:51:17', 'in Auftrag'),
(12, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 14:51:58', 'in Auftrag'),
(13, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 14:52:32', 'in Auftrag'),
(14, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 14:53:17', 'in Auftrag'),
(15, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 14:53:56', 'in Auftrag'),
(16, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 14:55:54', 'in Auftrag'),
(17, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 15:00:26', 'in Auftrag'),
(18, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 15:00:27', 'in Auftrag'),
(19, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 15:02:34', 'in Auftrag'),
(20, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 15:02:37', 'in Auftrag'),
(21, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 15:02:45', 'in Auftrag'),
(22, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 15:29:19', 'in Auftrag'),
(23, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 15:29:34', 'in Auftrag'),
(24, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 15:29:51', 'in Auftrag'),
(25, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 15:32:05', 'in Auftrag'),
(26, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:48:31', 'in Auftrag'),
(27, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:52:53', 'in Auftrag'),
(28, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:52:55', 'in Auftrag'),
(29, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:53:16', 'in Auftrag'),
(30, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:53:33', 'in Auftrag'),
(31, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:53:34', 'in Auftrag'),
(32, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:55:25', 'in Auftrag'),
(33, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:55:31', 'in Auftrag'),
(34, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:55:53', 'in Auftrag'),
(35, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:56:05', 'in Auftrag'),
(36, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:56:24', 'in Auftrag'),
(37, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:56:50', 'in Auftrag'),
(38, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:57:16', 'in Auftrag'),
(39, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:58:08', 'in Auftrag'),
(40, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:58:21', 'in Auftrag'),
(41, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:58:36', 'in Auftrag'),
(42, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:58:41', 'in Auftrag'),
(43, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 16:58:56', 'in Auftrag'),
(44, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 17:04:12', 'in Auftrag'),
(45, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 17:04:47', 'in Auftrag'),
(46, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 17:09:28', 'in Auftrag'),
(47, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 17:10:29', 'in Auftrag'),
(48, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 17:16:03', 'in Auftrag'),
(49, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 17:27:21', 'in Auftrag'),
(50, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 18:09:11', 'in Auftrag'),
(51, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 18:09:48', 'in Auftrag'),
(52, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 18:14:15', 'in Auftrag'),
(53, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 19:05:16', 'in Auftrag'),
(54, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 19:05:19', 'in Auftrag'),
(55, 'elias.maurer@student.reutlingen-university.de', '2024-05-24 19:05:32', 'in Auftrag'),
(56, 'elias_maurer@gmx.net', '2024-05-24 19:09:41', 'in Auftrag'),
(57, 'elias_maurer@gmx.net', '2024-05-24 21:18:46', 'in Auftrag'),
(58, 'elias_maurer@gmx.net', '2024-05-24 21:19:48', 'in Auftrag'),
(59, 'elias_maurer@gmx.net', '2024-05-24 21:22:27', 'in Auftrag'),
(60, 'elias_maurer@gmx.net', '2024-05-26 15:37:18', 'in Auftrag'),
(61, 'elias_maurer@gmx.net', '2024-05-26 15:39:49', 'in Auftrag'),
(62, 'elias_maurer@gmx.net', '2024-05-26 16:16:14', 'in Auftrag'),
(63, 'elias_maurer@gmx.net', '2024-05-26 16:23:08', 'in Auftrag'),
(64, 'elias_maurer@gmx.net', '2024-05-26 18:59:20', 'in Auftrag'),
(65, 'elias.maurer@student.reutlingen-university.de', '2024-05-27 12:43:51', 'in Auftrag'),
(66, 'elias_maurer@gmx.net', '2024-05-27 12:48:09', 'in Auftrag'),
(67, 'elias_maurer@gmx.net', '2024-05-27 12:56:26', 'in Auftrag'),
(68, 'elias_maurer@gmx.net', '2024-05-28 09:35:03', 'in Auftrag'),
(69, 'elias_maurer@gmx.net', '2024-05-28 09:40:00', 'in Auftrag'),
(70, 'elias_maurer@gmx.net', '2024-05-28 09:41:54', 'in Auftrag'),
(71, 'elias_maurer@gmx.net', '2024-05-28 13:03:37', 'in Auftrag'),
(72, 'elias_maurer@gmx.net', '2024-05-28 14:31:52', 'in Auftrag'),
(73, 'elias_maurer@gmx.net', '2024-05-28 14:37:44', 'in Auftrag'),
(74, 'elias_maurer@gmx.net', '2024-05-28 15:53:26', 'in Auftrag'),
(75, 'elias_maurer@gmx.net', '2024-05-28 16:47:19', 'in Auftrag'),
(76, 'elias_maurer@gmx.net', '2024-05-28 17:09:00', 'in Auftrag'),
(77, 'elias_maurer@gmx.net', '2024-05-28 17:56:07', 'in Auftrag'),
(78, 'elias_maurer@gmx.net', '2024-05-28 18:39:58', 'in Auftrag'),
(79, 'elias_maurer@gmx.net', '2024-05-28 18:42:05', 'in Auftrag'),
(80, 'elias_maurer@gmx.net', '2024-05-28 18:50:54', 'in Auftrag'),
(81, 'elias_maurer@gmx.net', '2024-05-28 18:51:08', 'in Auftrag'),
(82, 'elias_maurer@gmx.net', '2024-05-28 18:51:19', 'in Auftrag'),
(83, 'elias_maurer@gmx.net', '2024-05-28 18:51:27', 'in Auftrag'),
(84, 'elias_maurer@gmx.net', '2024-05-28 18:52:42', 'in Auftrag'),
(85, 'elias_maurer@gmx.net', '2024-05-28 20:51:32', 'in Auftrag'),
(86, '', '2024-05-29 16:47:35', 'in Auftrag'),
(87, '', '2024-05-29 16:47:45', 'in Auftrag'),
(88, '', '2024-05-29 16:54:34', 'in Auftrag'),
(89, 'elias_maurer@gmx.net', '2024-05-29 17:03:59', 'in Auftrag'),
(90, 'elias_maurer@gmx.net', '2024-05-30 15:31:12', 'in Auftrag'),
(91, 'elias_maurer@gmx.net', '2024-05-30 15:54:22', 'in Auftrag'),
(92, 'elias_maurer@gmx.net', '2024-05-30 16:18:34', 'in Auftrag'),
(93, 'elias_maurer@gmx.net', '2024-05-30 16:23:48', 'in Auftrag'),
(94, 'elias_maurer@gmx.net', '2024-05-30 17:04:03', 'in Auftrag'),
(95, 'aitana.toscano@gmx.de', '2024-05-30 18:27:38', 'in Auftrag'),
(96, 'paul.mattheus@gmx.de', '2024-06-02 14:51:37', 'in Auftrag'),
(97, 'elias_maurer@gmx.net', '2024-06-11 09:59:10', 'in Auftrag');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `warenkorbposition`
--

CREATE TABLE `warenkorbposition` (
  `warenkorbposition_id` int(11) NOT NULL,
  `warenkorbkopf_id` int(11) NOT NULL,
  `produkt_id` int(11) NOT NULL,
  `menge` int(11) DEFAULT NULL,
  `preis` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `warenkorbposition`
--

INSERT INTO `warenkorbposition` (`warenkorbposition_id`, `warenkorbkopf_id`, `produkt_id`, `menge`, `preis`) VALUES
(8, 1, 551, 1, '1399.99'),
(9, 1, 552, 1, '700.00'),
(10, 1, 561, 1, '1450.00'),
(11, 1, 562, 1, '1000.00'),
(12, 4, 551, 1, '1399.99'),
(13, 4, 552, 1, '700.00'),
(14, 12, 551, 1, '1399.99'),
(15, 12, 552, 1, '700.00'),
(16, 12, 561, 1, '1450.00'),
(17, 12, 562, 2, '1000.00'),
(18, 13, 551, 5, '1399.99'),
(19, 13, 552, 1, '700.00'),
(20, 14, 551, 5, '1399.99'),
(21, 14, 552, 1, '700.00'),
(22, 54, 551, 5, '1399.99'),
(23, 54, 552, 1, '700.00'),
(24, 55, 551, 1, '1399.99'),
(25, 55, 552, 3, '700.00'),
(26, 55, 561, 2, '1450.00'),
(27, 55, 562, 1, '1000.00'),
(28, 55, 571, 1, '450.00'),
(29, 55, 572, 2, '250.00'),
(30, 56, 551, 1, '1399.99'),
(31, 56, 552, 1, '700.00'),
(32, 56, 571, 1, '450.00'),
(33, 56, 572, 3, '250.00'),
(34, 57, 561, 1, '1450.00'),
(35, 57, 562, 1, '1000.00'),
(36, 57, 571, 1, '450.00'),
(37, 57, 572, 1, '250.00'),
(38, 58, 561, 1, '1450.00'),
(39, 58, 562, 1, '1000.00'),
(40, 58, 571, 1, '450.00'),
(41, 58, 572, 1, '250.00'),
(42, 59, 561, 1, '1450.00'),
(43, 59, 562, 1, '1000.00'),
(44, 59, 571, 1, '450.00'),
(45, 59, 572, 1, '250.00'),
(46, 60, 551, 1, '1399.99'),
(47, 60, 552, 1, '700.00'),
(48, 60, 571, 3, '450.00'),
(49, 60, 572, 1, '250.00'),
(50, 61, 551, 1, '1399.99'),
(51, 61, 552, 1, '700.00'),
(52, 61, 571, 3, '450.00'),
(53, 61, 572, 1, '250.00'),
(54, 62, 551, 1, '1399.99'),
(55, 62, 552, 1, '700.00'),
(56, 62, 571, 1, '450.00'),
(57, 62, 572, 3, '250.00'),
(58, 62, 562, 1, '1000.00'),
(59, 63, 551, 1, '1399.99'),
(60, 63, 552, 1, '700.00'),
(61, 63, 561, 1, '1450.00'),
(62, 63, 562, 1, '1000.00'),
(63, 64, 551, 4, '1399.99'),
(64, 64, 552, 2, '700.00'),
(65, 64, 561, 3, '1450.00'),
(66, 64, 562, 1, '1000.00'),
(67, 65, 551, 1, '1399.99'),
(68, 65, 552, 2, '700.00'),
(69, 65, 562, 4, '1000.00'),
(70, 66, 551, 1, '1399.99'),
(71, 67, 551, 1, '1399.99'),
(72, 67, 552, 1, '700.00'),
(73, 67, 561, 1, '1450.00'),
(74, 68, 551, 3, '1399.99'),
(75, 68, 552, 1, '700.00'),
(76, 69, 551, 5, '1399.99'),
(77, 69, 562, 10, '1000.00'),
(78, 70, 551, 5, '1399.99'),
(79, 70, 562, 10, '1000.00'),
(80, 71, 551, 1, '1399.99'),
(81, 71, 552, 1, '700.00'),
(82, 71, 561, 1, '1450.00'),
(83, 71, 562, 1, '1000.00'),
(84, 72, 551, 3, '1399.99'),
(85, 72, 552, 2, '700.00'),
(86, 72, 562, 2, '1000.00'),
(87, 73, 551, 3, '1399.99'),
(88, 73, 552, 2, '700.00'),
(89, 73, 562, 2, '1000.00'),
(90, 74, 551, 1, '1399.99'),
(91, 74, 552, 1, '700.00'),
(92, 75, 551, 1, '1399.99'),
(93, 75, 552, 1, '700.00'),
(94, 76, 551, 1, '1399.99'),
(95, 76, 552, 1, '700.00'),
(96, 76, 562, 1, '1000.00'),
(97, 77, 551, 1, '1399.99'),
(98, 77, 552, 1, '700.00'),
(99, 77, 562, 1, '1000.00'),
(100, 78, 551, 1, '1399.99'),
(101, 78, 552, 1, '700.00'),
(102, 78, 561, 1, '1450.00'),
(103, 79, 551, 1, '1399.99'),
(104, 79, 552, 1, '700.00'),
(105, 79, 561, 1, '1450.00'),
(106, 80, 551, 1, '1399.99'),
(107, 80, 552, 1, '700.00'),
(108, 80, 561, 1, '1450.00'),
(109, 81, 551, 1, '1399.99'),
(110, 81, 552, 1, '700.00'),
(111, 81, 561, 1, '1450.00'),
(112, 82, 551, 1, '1399.99'),
(113, 82, 552, 1, '700.00'),
(114, 82, 561, 1, '1450.00'),
(115, 83, 561, 1, '1450.00'),
(116, 83, 571, 1, '450.00'),
(117, 84, 561, 1, '1450.00'),
(118, 84, 571, 1, '450.00'),
(119, 85, 561, 1, '1450.00'),
(120, 85, 571, 1, '450.00'),
(121, 86, 551, 1, '1399.99'),
(122, 86, 552, 1, '700.00'),
(123, 87, 551, 1, '1399.99'),
(124, 87, 552, 1, '700.00'),
(125, 88, 551, 1, '1399.99'),
(126, 88, 552, 1, '700.00'),
(127, 89, 551, 1, '1399.99'),
(128, 89, 552, 1, '700.00'),
(129, 90, 551, 2, '1399.99'),
(130, 90, 552, 2, '700.00'),
(131, 90, 562, 1, '1000.00'),
(132, 91, 551, 2, '1399.99'),
(133, 91, 552, 2, '700.00'),
(134, 91, 562, 1, '1000.00'),
(135, 92, 551, 1, '1399.99'),
(136, 92, 561, 1, '1450.00'),
(137, 92, 563, 1, '700.00'),
(138, 93, 551, 1, '1399.99'),
(139, 94, 551, 1, '1399.99'),
(140, 94, 552, 1, '700.00'),
(141, 94, 562, 1, '1000.00'),
(142, 95, 551, 1, '1399.99'),
(143, 95, 552, 1, '700.00'),
(144, 95, 561, 3, '1450.00'),
(145, 96, 551, 1, '1399.99'),
(146, 96, 552, 1, '700.00'),
(147, 96, 561, 1, '1450.00'),
(148, 97, 551, 1, '1399.99'),
(149, 97, 552, 1, '700.00');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `kunden`
--
ALTER TABLE `kunden`
  ADD PRIMARY KEY (`KundenID`);

--
-- Indizes für die Tabelle `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`Benutzername`);

--
-- Indizes für die Tabelle `produkte`
--
ALTER TABLE `produkte`
  ADD PRIMARY KEY (`ProduktID`);

--
-- Indizes für die Tabelle `punkte`
--
ALTER TABLE `punkte`
  ADD PRIMARY KEY (`BenutzernameID`);

--
-- Indizes für die Tabelle `rechnungskopf`
--
ALTER TABLE `rechnungskopf`
  ADD PRIMARY KEY (`rechnungskopf_id`);

--
-- Indizes für die Tabelle `rechnungsposition`
--
ALTER TABLE `rechnungsposition`
  ADD PRIMARY KEY (`line_item_id`);

--
-- Indizes für die Tabelle `testtable`
--
ALTER TABLE `testtable`
  ADD PRIMARY KEY (`warenkorbposition_id`);

--
-- Indizes für die Tabelle `warenkorbkopf`
--
ALTER TABLE `warenkorbkopf`
  ADD PRIMARY KEY (`warenkorb_id`);

--
-- Indizes für die Tabelle `warenkorbposition`
--
ALTER TABLE `warenkorbposition`
  ADD PRIMARY KEY (`warenkorbposition_id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `rechnungskopf`
--
ALTER TABLE `rechnungskopf`
  MODIFY `rechnungskopf_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT für Tabelle `rechnungsposition`
--
ALTER TABLE `rechnungsposition`
  MODIFY `line_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=245;

--
-- AUTO_INCREMENT für Tabelle `testtable`
--
ALTER TABLE `testtable`
  MODIFY `warenkorbposition_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT für Tabelle `warenkorbkopf`
--
ALTER TABLE `warenkorbkopf`
  MODIFY `warenkorb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT für Tabelle `warenkorbposition`
--
ALTER TABLE `warenkorbposition`
  MODIFY `warenkorbposition_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
