<?php 
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$json_string= $_POST["jsonstring_for_php"] ?? null;
$result_array = json_decode($json_string, true);

$_SESSION['array_for_rechnungspos'] = $result_array;
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Webshop_DB";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['user_id'];

$sql_insert_data_into_shoppingcart_head =
"
INSERT INTO warenkorbkopf (username_fk, datumDerErstellung, status) VALUES ('$username', NOW(), 'in Auftrag');
";
$result_shoppingcart_head = $conn->query($sql_insert_data_into_shoppingcart_head);

$sql_variable_warenkorbkopf_id = "SELECT MAX(warenkorb_id) as max_warenkorb_id FROM warenkorbkopf WHERE username_fk = '$username'";
$result_id_number = $conn->query($sql_variable_warenkorbkopf_id);

if ($result_id_number->num_rows > 0) {
  $row = $result_id_number->fetch_assoc();
  $warenkorbkopf_id = $row["max_warenkorb_id"]; // Should be unique for each user
}

$_SESSION['shoppingcart_number'] = $warenkorbkopf_id;

$stmt = $conn->prepare("INSERT INTO warenkorbposition (warenkorbkopf_id, produkt_id, menge, preis) VALUES (?, ?, ?, ?)");
$stmt->bind_param("iiid",  $warenkorbkopf_id, $item_number_var, $item_quantity_var, $item_price_var);
// $stmt = $conn->prepare("INSERT INTO testtable (warenkorbposition_id, menge, preis) VALUES (?, ?, ?)");
// $stmt->bind_param("iid", $warenkorb_position_id, $item_quantity_var, $item_price_var);



foreach ($result_array as $item) {
  $item_name_var = $item['itemName']; 
  $item_quantity_var = $item['quantity']; 
  $item_price_var = $item['price']; 
  $item_number_var = $item['number']; 
  $item_discount_var = $item['discount']; 

    if ($stmt->execute()) {
        // echo "Record inserted successfully\n";
    } else {
        // echo "Error: " . $stmt->error . "\n";
    }
}

// Close the statement and connection
$stmt->close();
$conn->close();

?>

<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="../assets/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.111.3">
    <title>Easybike.</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/checkout/">
    <link rel="stylesheet" href="../bootstrap stuff/css/bootstrap.min.css">
    <link rel="stylesheet" href="../CSS/checkout.css">
    <!-- <script src="../JS/Checkout.js"></script> <script src="checkout.js"></script> -->
    



    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        width: 100%;
        height: 3rem;
        background-color: rgba(0, 0, 0, .1);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }

      .btn-bd-primary {
        --bd-violet-bg: #712cf9;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

        --bs-btn-font-weight: 600;
        --bs-btn-color: var(--bs-white);
        --bs-btn-bg: var(--bd-violet-bg);
        --bs-btn-border-color: var(--bd-violet-bg);
        --bs-btn-hover-color: var(--bs-white);
        --bs-btn-hover-bg: #6528e0;
        --bs-btn-hover-border-color: #6528e0;
        --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
        --bs-btn-active-color: var(--bs-btn-hover-color);
        --bs-btn-active-bg: #5a23c8;
        --bs-btn-active-border-color: #5a23c8;
      }
      .bd-mode-toggle {
        z-index: 1500;
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="checkout.css" rel="stylesheet">
  </head>
  <body class="bg-body-tertiary">
    <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
      <symbol id="check2" viewBox="0 0 16 16">
        <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
      </symbol>
      <symbol id="circle-half" viewBox="0 0 16 16">
        <path d="M8 15A7 7 0 1 0 8 1v14zm0 1A8 8 0 1 1 8 0a8 8 0 0 1 0 16z"/>
      </symbol>
      <symbol id="moon-stars-fill" viewBox="0 0 16 16">
        <path d="M6 .278a.768.768 0 0 1 .08.858 7.208 7.208 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277.527 0 1.04-.055 1.533-.16a.787.787 0 0 1 .81.316.733.733 0 0 1-.031.893A8.349 8.349 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.752.752 0 0 1 6 .278z"/>
        <path d="M10.794 3.148a.217.217 0 0 1 .412 0l.387 1.162c.173.518.579.924 1.097 1.097l1.162.387a.217.217 0 0 1 0 .412l-1.162.387a1.734 1.734 0 0 0-1.097 1.097l-.387 1.162a.217.217 0 0 1-.412 0l-.387-1.162A1.734 1.734 0 0 0 9.31 6.593l-1.162-.387a.217.217 0 0 1 0-.412l1.162-.387a1.734 1.734 0 0 0 1.097-1.097l.387-1.162zM13.863.099a.145.145 0 0 1 .274 0l.258.774c.115.346.386.617.732.732l.774.258a.145.145 0 0 1 0 .274l-.774.258a1.156 1.156 0 0 0-.732.732l-.258.774a.145.145 0 0 1-.274 0l-.258-.774a1.156 1.156 0 0 0-.732-.732l-.774-.258a.145.145 0 0 1 0-.274l.774-.258c.346-.115.617-.386.732-.732L13.863.1z"/>
      </symbol>
      <symbol id="sun-fill" viewBox="0 0 16 16">
        <path d="M8 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/>
      </symbol>
    </svg>

    <div class="blurry-background"></div>

    
<div class="container">
<main>
        <div class="py-5 text-center">
          <h2>Checkout</h2>
        </div>

        <div class="row g-5">
          <div class="col-md-5 col-lg-4 order-md-last">
            <h4 class="d-flex justify-content-between align-items-center mb-3">
              <span class="text-primary">Your cart</span>
            </h4>
            <ul id="checkoutList" class="list-group mb-3"></ul>

            <form class="card p-2">
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Promo code">
                <button type="submit" class="btn btn-secondary">Redeem</button>
              </div>
            </form>
          </div>

          <div class="col-md-7 col-lg-8">
            <h4 class="mb-3">Billing address</h4>
            <form action="OrderReview.php" method="POST">
              <div class="row g-3">
                <div class="col-sm-6">
                  <label for="firstName" class="form-label">First name</label>
                  <input type="text" class="form-control" name="firstName" id="firstName" placeholder="" value="" required>
                  <div class="invalid-feedback">Valid first name is required.</div>
                </div>

                <div class="col-sm-6">
                  <label for="lastName" class="form-label">Last name</label>
                  <input type="text" class="form-control" name="lastName" id="lastName" placeholder="" value="" required>
                  <div class="invalid-feedback">Valid last name is required.</div>
                </div>

                <div class="col-12">
                  <label for="username" class="form-label">Username</label>
                  <div class="input-group has-validation">
                    <span class="input-group-text">@</span>
                    <input type="text" class="form-control" name="username" id="username" placeholder="Username" required>
                    <div class="invalid-feedback">Your username is required.</div>
                  </div>
                </div>

                <div class="col-12">
                  <label for="address" class="form-label">Address</label>
                  <input type="text" class="form-control" name="address" id="address" placeholder="Strassenname Nummer" required>
                  <div class="invalid-feedback">Please enter your shipping address.</div>
                </div>
                
                <div class="col-12">
                  <label for="city" class="form-label">City</label>
                  <input type="text" class="form-control" name="city" id="city" placeholder="Reutlingen" required>
                  <div class="invalid-feedback">Please enter your city.</div>
                </div>

                <div class="col-md-5">
                  <label for="country" class="form-label">Country</label>
                  <select class="form-select" name="country" id="country" required>
                    <option value="">Choose...</option>
                    <option>Germany</option>
                  </select>
                  <div class="invalid-feedback">Please select a valid country.</div>
                </div>

                <div class="col-md-4">
                  <label for="state" class="form-label">Bundesstaat</label>
                  <select class="form-select" name="state" id="state" name="state" required>
                    <option value="">Choose...</option>
                    <option>Baden-Württemberg</option>
                    <option>Bavaria (Bayern)</option>
                    <option>Berlin</option>
                    <option>Brandenburg</option>
                    <option>Bremen</option>
                    <option>Hamburg</option>
                    <option>Hesse (Hessen)</option>
                    <option>Lower Saxony (Niedersachsen)</option>
                    <option>Mecklenburg-Vorpommern</option>
                    <option>North Rhine-Westphalia (Nordrhein-Westfalen)</option>
                    <option>Rhineland-Palatinate (Rheinland-Pfalz)</option>
                    <option>Saarland</option>
                    <option>Saxony (Sachsen)</option>
                    <option>Saxony-Anhalt (Sachsen-Anhalt)</option>
                    <option>Schleswig-Holstein</option>
                    <option>Thuringia (Thüringen)</option>
                  </select>
                  <div class="invalid-feedback">Please provide a valid state.</div>
                </div>

                <div class="col-md-3">
                  <label for="zip" class="form-label">Zip</label>
                  <input type="text" class="form-control" name="zip" id="zip" placeholder="" required>
                  <div class="invalid-feedback">Zip code required.</div>
                </div>
              </div>

              <hr class="my-4">

              <div class="form-check">
                <input type="checkbox" class="form-check-input" name="same-address"  id="same-address">
                <label class="form-check-label" for="same-address">Shipping address is the same as my billing address</label>
              </div>

              <hr class="my-4">

              <h4 class="mb-3">Shipment</h4>
              <div id="shippingMethod" name="shippingMethod" class="my-3">
                <div class="form-check">
                  <input id="standard" name="shipping" type="radio" class="form-check-input" checked required value="standard">
                  <label class="form-check-label" for="standard">DPD (€3,99)</label>
                </div>
                <div class="form-check">
                  <input id="express" name="shipping" type="radio" class="form-check-input" required value="express">
                  <label class="form-check-label" for="express">DHL (€8,99)</label>
                </div>
                <div class="form-check">
                  <input id="overnight" name="shipping" type="radio" class="form-check-input" required value="overnight">
                  <label class="form-check-label" for="overnight">DHL EXPRESS (€14,00)</label>
                </div>
              </div>





              <hr class="my-4">

              <h4 class="mb-3">Payment</h4>
              <div class="my-3">
                <div class="form-check">
                  <input id="paymentMethod" name="paymentMethod"  type="radio" class="form-check-input" required>
                  <label class="form-check-label" for="paymentMethod">PayPal</label>
                </div>
              </div>

              <hr class="my-4">

              <div class="form-check">
                <input type="checkbox" class="form-check-input" name="terms" id="terms" required>
                <label class="form-check-label" for="terms">I accept all Terms of Privacy</label>
              </div>

              <hr class="my-4">

              <button class="w-100 btn btn-primary btn-lg" type="submit">Continue to checkout</button>
            </form>
          </div>
        </div>
      </main>

  <footer class="my-5 pt-5 text-body-secondary text-center text-small">
    <p class="mb-1">&copy; 2017–2023 easybike.</p>
    
  </footer>
</div>


    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

    <!-- <script src="checkout.js"></script> -->

      <script>
        function sending_data(){
          window.location.href = "OrderReivew.php";

        }

    </script>
  </body>
</html>