<?php 
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);
// Rest of your code
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Webshop_DB";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];

if ($user_id) {
  $user_id = $_SESSION['user_id'];
} else {
  header('Location: ../index.html');
  exit();
}



$sql_user_information = "
SELECT Vorname, Nachname
FROM Kunden
WHERE KundenID= '$user_id'
";
$result_user_info= $conn->query($sql_user_information);


$row_user_info = $result_user_info->fetch_assoc();

$firstname = $row_user_info["Vorname"];
$lastname = $row_user_info["Nachname"];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dankes-Seite</title>
    <link rel="stylesheet" href="../bootstrap stuff/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../CSS/shophelm1.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</head>
<body>
    <header>
        <nav class="navbar navbar-dark bg-dark fixed-top bg-transparent">
            <div class="container-fluid">
              <a class="navbar-brand" href="../PHP/logout.php" style="color: rgb(255, 0, 0);"><b><button class=" btn btn-bd-primary-2 btn-lg">easybike.</button></b></a>
            
                <div class="offcanvas-body">
                  <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                    
                    
                  </ul> 
                </div>
              </div>
            </div>
          </nav>
    </header>
   
    <section>
      <div class="container text-center" style="margin-top: 250px;">
            <div class="card" style="width: 100%; height: 100%;">
              <div class="card-body">
                <h6 style="color: rgb(165, 165, 165);">Vielen Dank fuer deinen Einkauf</h6>
                <br>
                <p class="card-text"> Das ganze MyEasyBike-Team wuenscht dir ganz viel Spass mit deinen neuen Artikeln<br>
                     <br>
              </div>
              
              
            </div>
      </section>
      
    
    
</body>
</html>

<?php 

try{
        $user_name = $_SESSION['user_id'];

        $mail = new PHPMailer(true);
        // Server settings
        try{
            $mail->isSMTP(); // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com'; // Specify main and backup SMTP servers
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = 't35tm41l3l145@gmail.com'; // SMTP username
            $mail->Password = 'kerx vbpv xccr rbit'; // SMTP password
            $mail->SMTPSecure = 'tls'; // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587; // TCP port to connect to   
    
            //Email content
    
            $mail->setFrom('t35tm41l3l145@gmail.com', 'Elias Maurer');
            $mail->addAddress($user_name, $firstname . '' . $lastname);
    
            ob_start(); // Start output buffering
            require '../HTML/emails/orderReviewEmail.php'; // Include PHP script
            $htmlContent = ob_get_clean();

            // Content
            $mail->isHTML(true);                                   // Set email format to HTML
            $mail->Subject = 'Bestelluebersicht' . $user_name;
            $mail->AddEmbeddedImage('../Images/logo.png', 'logo_2u');

            $mail->Body = $htmlContent;  
            
            $mail->send();
            echo 'Message has been sent';
            // header("Location: ../HTML/registrierungsBestaetigung.html");
            exit();
        }catch(Exception $e){
            echo "Error creating PHPMailer object: " . $e->getMessage();
        }
            
    
        $conn->close();

}catch (Exception $e) {
    echo "Error creating PHPMailer object: " . $e->getMessage();
}



 
