<?php

session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
  // Subtract converted points from the total cost
  $total_cost -= $umgewandelte_punkte * 0.01;
}


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Webshop_DB";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$firstname = $_POST["firstName"];
$lastname = $_POST["lastName"];
$username = $_POST["username"];
$address = $_POST["address"];
$country = $_POST["country"];
$state = $_POST["state"];
$zip = $_POST["zip"];
$same_address = $_POST["same-address"];
$shippingMethod = $_POST["shipping"];
$city = $_POST["city"];

$shoppingcart_number_for_sql = $_SESSION['shoppingcart_number'];

$username = $_SESSION["user_id"];
$sql_update_punkte = "UPDATE Punkte SET Punkte = Punkte + 25 WHERE BenutzernameID = '$username'";
$result = $conn->query($sql_update_punkte);
// Check if user exists in Punkte table


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order-Review</title>
    <link rel="stylesheet" href="../bootstrap stuff/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../CSS/shophelm1.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</head>
<body>
    <header>
        <nav class="navbar navbar-dark bg-dark fixed-top bg-transparent">
            <div class="container-fluid">
              <a class="navbar-brand" href="../index.html" style="color: rgb(255, 0, 0);"><b><button class=" btn btn-bd-primary-2 btn-lg">easybike.</button></b></a>
              <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar" aria-label="Toggle navigation">
                <span><b><ion-icon name="grid-outline" style="color: red; height: 60px; width: 50px;"></ion-icon></b></span>
              </button>
              <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel" style="color: rgb(255, 0, 0);">
                <div class="offcanvas-header">
                  <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel" style="color: rgb(255, 0, 0);"><b>easybike.</b></h5>
                  <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                  <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                    <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="color: white;">
                        MYEASYBIKE
                      </a>
                      <ul class="dropdown-menu dropdown-menu-dark">
                        <li><a class="dropdown-item" href="../index.html" style="color: white;">Hauptseite</a></li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </nav>
    </header>
   
    <section>
      <div class="container text-center" style="margin-top: 250px;">
        <div class="card" style="width: 100%; height: 100%;">
          <div class="card-body">
            <h6 style="color: rgb(165, 165, 165);">Kauf Uebersicht</h6>
            <br>
            <p class="card-text"><br></p>
            <table class="table table-striped">
              <thead>
                <tr>
                    <th>Artikel ID</th>
                    <th>Artikel Name</th>
                    <th>Artikel Beschreibung</th>
                    <th>Artikelmenge</th>
                    <th>Artikelpreis</th>
                    <th>Bestellnummer</th>
                    <th>Einzelpreis</th>
                    <th>Summe</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $sql_get_items_from_shopping_cart = "
                  SELECT wp.*, p.*
                  FROM warenkorbposition wp
                  JOIN produkte p ON wp.produkt_id = p.ProduktID
                  WHERE wp.warenkorbkopf_id = '$shoppingcart_number_for_sql'
                ";

                $result_items_from_shopping_cart = $conn->query($sql_get_items_from_shopping_cart);

                $total_sum = 0;
                if ($result_items_from_shopping_cart->num_rows > 0) {
                  while ($row = $result_items_from_shopping_cart->fetch_assoc()) {
                    $kundenid = $row["warenkorbkopf_id"];
                      echo "<tr>";
                      echo "<td>" . htmlspecialchars($row["produkt_id"]) . "</td>";
                      echo "<td>" . htmlspecialchars($row["ProduktName"]) . "</td>";
                      echo "<td>" . htmlspecialchars($row["Beschreibung"]) . "</td>";
                      echo "<td>" . htmlspecialchars($row["menge"]) . "</td>";
                      echo "<td>" . htmlspecialchars($row["preis"]) . "</td>";
                      echo "<td>" . htmlspecialchars($row["warenkorbkopf_id"]) . "</td>";
                      if (intval($row["menge"]) >= 10) {
                        $discounted_val_20_percent = floatval($row["preis"]) * 0.8;
                        echo "<td>" . $discounted_val_20_percent . "</td>";
                        $val_for_price_sum = $discounted_val_20_percent * intval($row["menge"]);
                        echo "<td>" . $val_for_price_sum . "</td>";
                      } elseif (intval($row["menge"]) >= 5) {
                        $discounted_val_10_percent = floatval($row["preis"]) * 0.9;
                        echo "<td>" . $discounted_val_10_percent . "</td>";
                        $val_for_price_sum = $discounted_val_10_percent * intval($row["menge"]);
                        echo "<td>" . $val_for_price_sum . "</td>"; 
                    } else {
                        echo "<td>" . $row["preis"] . "</td>";
                        $val_for_price_sum = floatval($row["preis"]) * intval($row["menge"]);
                        echo "<td>" . $val_for_price_sum . "</td>";  
                    }
                    echo "</tr>";
                    $total_sum += $val_for_price_sum;
                  }
                }

                if($shippingMethod==="standard"){
                  $kosten_fuer_versand = floatval(3.99) ;
                }elseif($shippingMethod==="express"){
                  $kosten_fuer_versand = floatval(8.99) ;
                }else{
                  $kosten_fuer_versand = floatval(14.00) ;
                }
                
                $total_cost = $total_sum + $kosten_fuer_versand;

                $sql_punkte_umwandeln = "SELECT punkte FROM punkte WHERE BenutzernameID ='$username' "; 
                $result_punkte_from_database = $conn->query($sql_punkte_umwandeln);

                $row = $result_punkte_from_database->fetch_assoc();
                $punkte_from_database = $row["punkte"];

                $umgewandelte_punkte = floatval($punkte_from_database) * 0.1; 

                echo "<tr>";
                echo "<td>Versandart</td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                if($shippingMethod==="standard"){
                  echo "<td>DPD (3.99€)  </td>";
                }elseif($shippingMethod==="express"){
                  echo "<td>DHL (8.99€)  </td>";
                }else{
                  echo "<td>DHL (14.00€)  </td>";
                }
                echo "</tr>";

                echo "<tr>";
                echo '<td><button type="submit" name="submit" class="btn btn-primary">Punkte von Summe abziehen</button></td>';
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td>" . $umgewandelte_punkte . " cent</td>";
                echo "</tr>";

                echo "<tr>";
                echo "<td>Gesammtsumme</td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td>$total_cost</td>";
                echo "</tr>";

                


                ?>
              </tbody>
            </table>
            <form action="dankesseite.php" method="post">
              <button type="submit" class="btn btn-primary">Jetzt bezahlen und bestellen</button>
            </form>
          </div>
        </div>
      </div>
    </section>
</body>
</html>

<?php

$paymentMethod = "Paypal";
$sql_input_rechnungskopf = "INSERT INTO rechnungskopf (kunden_id, rechnungskopf_date, summe, versandart, bezahlungsart, kundenVorname, kundenNachname, kundenBundesstaat, zipcode, username, strasse, stadt) 
VALUES ('$kundenid', NOW(), '$total_cost', '$shippingMethod', '$paymentMethod', '$firstname', '$lastname', '$state', '$zip', '$username', '$address', '$city')
";
$result_input_rechnungskopf = $conn->query($sql_input_rechnungskopf);

$_SESSION["shippingMethod"] = $shippingMethod;

$sql_variable_rechnungskopf_id = "SELECT MAX(rechnungskopf_id) as max_rechnungskopf_id FROM rechnungskopf WHERE username = '$username'";
$result_max_rechnungskopf_id = $conn->query($sql_variable_rechnungskopf_id);

if ($result_max_rechnungskopf_id->num_rows > 0) {
  $row = $result_max_rechnungskopf_id->fetch_assoc();
  $warenkorbkopf_id = $row["max_rechnungskopf_id"]; // Should be unique for each user
}

$stmt = $conn->prepare("INSERT INTO rechnungsposition (rechnungskopf_id, produkt_id, menge, preis) VALUES (?, ?, ?,?)");
$stmt->bind_param("iiid",  $kundenid, $item_number_var, $item_quantity_var, $item_price_var);
// $stmt = $conn->prepare("INSERT INTO testtable (warenkorbposition_id, menge, preis) VALUES (?, ?, ?)");
// $stmt->bind_param("iid", $warenkorb_position_id, $item_quantity_var, $item_price_var);

$result_array = $_SESSION['array_for_rechnungspos'];

foreach ($result_array as $item) {
  $item_name_var = $item['itemName']; 
  $item_quantity_var = $item['quantity']; 
  $item_price_var = $item['price']; 
  $item_number_var = $item['number']; 

    if ($stmt->execute()) {
        // echo "Record inserted successfully\n";
    } else {
        // echo "Error: " . $stmt->error . "\n";
    }
}

// Close the statement and connection
$stmt->close();
$conn->close();

?>