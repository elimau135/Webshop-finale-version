

<?php
echo "wekcone";
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Webshop_DB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$userID = $_POST["user_mail"];
$newpassword = $_POST["pw1"];

// Hash the password
$hashedPassword = password_hash($newpassword, PASSWORD_DEFAULT);
//ist eingabe pw == dem standardpasswort - falls ja -> verlinkung zu einer neuen seite und pw ist dann empty

// SQL query to insert data
$sql = "UPDATE Kunden SET BenutzerPW = '$hashedPassword' WHERE KundenID = '$userID'";


if ($conn->query($sql) === TRUE) {
    // Insert successful
    header("Location: ../index.html");
} else {
    // Insert failed
    echo "Error: " . $sql . "<br>" . $conn->error;
}

?>
