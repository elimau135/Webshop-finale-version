<?php 
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);


// Rest of your code
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php';
try{
    $pageRequester_registration = isset($_POST['the_page_requester_registration']) ? $_POST['the_page_requester_registration'] : null;
    $pageRequester_login = isset($_POST['the_page_requester_login']) ? $_POST['the_page_requester_login'] : null;
    $pageRequester_logout = isset($_POST['the_page_requester_logout']) ? $_POST['the_page_requester_logout'] : null;

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "Webshop_DB";
        $conn = new mysqli($servername, $username, $password, $dbname);


        $password_string = 'abcdefghijklmnpqrstuwxyzABCDEFGHJKLMNPQRSTUWXYZ23456789';
        $pw = substr(str_shuffle($password_string), 0, 6);
        
        // Sample data to be inserted
        $user_name = $_POST["user_mail"];
        //$pw = $_POST["pw"];
        $hashedPassword = password_hash($pw, PASSWORD_DEFAULT);
        $firstname = $_POST["fname"];
        $lastname = $_POST["lname"];
        $user_date_now = date("Y-m-d");
        $user_weekday_now = date("l");
        $screen_resolution = $_POST["res"];
        $os = $_POST["os"];
        $online_status = "off";

        echo $pageRequester_registration;
    
        require_once 'google_auth/PHPGangsta/GoogleAuthenticator.php';
    
        $ga = new PHPGangsta_GoogleAuthenticator();
    
        $secret = $ga->createSecret(); // Should be unique for each user
    
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
    
        $sql = "INSERT INTO Kunden (KundenID, generiertesPW, Vorname, Nachname, DatumVergangen, WochentagVergangen, Aufloesung, betriebssystem, GoogleOAuth, DatumJetzt, WochentagJetzt, BenutzerPW)
        VALUES ('$user_name', '$hashedPassword', '$firstname', '$lastname', '$user_date_now', '$user_weekday_now', '$screen_resolution', '$os', '$secret', NULL, NULL, NULL )";
    
        if ($conn->query($sql) === TRUE) {
            echo "Data inserted successfully";
        }else {
    
            if($conn->errno == 1062){
                header("Location:../index.html");
                exit();
            }else{
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            
        }
        if (isset($conn)){
            $conn->close();
        }
        //gut35pw_v0n_3L145.M
    
        $mail = new PHPMailer(true);
        // Server settings
        try{
            $mail->isSMTP(); // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com'; // Specify main and backup SMTP servers
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = 't35tm41l3l145@gmail.com'; // SMTP username
            $mail->Password = 'kerx vbpv xccr rbit'; // SMTP password
            $mail->SMTPSecure = 'tls'; // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587; // TCP port to connect to   
    
            //Email content
    
            $mail->setFrom('t35tm41l3l145@gmail.com', 'Elias Maurer');
            $mail->addAddress($user_name,'Elias Maurer');
    
            // Content
            $mail->isHTML(true);                                   // Set email format to HTML
            $mail->Subject = '';
            
            $htmlContent = file_get_contents('../HTML/emails/registrierungsmaildesign.php');
            $htmlContent = str_replace('$pw', $pw, $htmlContent); // Replace $pw with the actual password
            $htmlContent = str_replace('$secret', $secret, $htmlContent); // Replace $secret with the actual secret
            
            $mail->Body = $htmlContent;  
            
            $_SESSION['$pw_standard_registration'] = $pw;
            $_SESSION['$secret_registration'] = $secret;
    
            
            // Send the email
            $mail->send();
            echo 'Message has been sent';
            header("Location: ../HTML/registrierungsBestaetigung.html");
            exit();
        }catch(Exception $e){
            echo "Error creating PHPMailer object: " . $e->getMessage();
        }
            
    

}catch (Exception $e) {
    echo "Error creating PHPMailer object: " . $e->getMessage();
}
