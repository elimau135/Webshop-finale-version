<?php
// Start the session
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();


// if ($_SERVER["REQUEST_METHOD"] == "POST") {
//     logout();
// }

logout();
function logout()
{
    // Ensure the user_id is set in the session
    if (!isset($_SESSION['user_id'])) {
        die("User not logged in");
    }

    $nameOfUser = $_SESSION['user_id'];
    var_dump($nameOfUser);

    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "Webshop_DB";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("DELETE FROM Logs WHERE Benutzername = ?");
    if (!$stmt) {
        die("Preparation failed: " . $conn->error);
    }

    $stmt->bind_param("s", $nameOfUser);
    $resultSQLOnline = $stmt->execute();

    if (!$resultSQLOnline) {
        die("Error executing SQL query: " . $stmt->error);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
    $_SESSION = array();
    session_destroy();

    // Redirect after successful logout
    header("Location: ../index.html", true, 302);
    exit();
}

?>
