<?php 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Webshop_DB";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_POST["usermail_from_javascript"];

$sql_name_exists = "SELECT * FROM Kunden WHERE KundenID = '$username'";
$result = $conn->query($sql_name_exists);

if($result->num_rows>0){
echo "email does exists";
}else{
    echo "email does not exists";
}


$conn->close();
