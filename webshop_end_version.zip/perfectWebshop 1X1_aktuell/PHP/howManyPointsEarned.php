<?php 



$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Webshop_DB";


$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['user_id'];

$sqlPointsEarned = "SELECT punkte from punkte WHERE BenutzernameID = '$username'";
$result = $conn->query($sqlPointsEarned);

if($result ->num_rows > 0){
    $row = $result->fetch_assoc();
    $pointsEarned = $row['punkte'];
}else{
    $pointsEarned = 0;
}

echo $pointsEarned;

$conn->close();
