
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

session_start();

try {
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "Webshop_DB";

    // Include Google Authenticator library
    require_once 'google_auth/PHPGangsta/GoogleAuthenticator.php';

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $username = $conn->real_escape_string($_POST["user_mail"]);
    $_SESSION['user_id'] = $username;
    $pw = $_POST["pw"];
    $user_date_now = date("Y-m-d");
    $user_weekday_now = date("l");
    $screen_resolution = $_POST["res"];
    $os = $_POST["os"];
    $code2fa = $_POST["code2FA"];

    $sql_update_dates = "UPDATE Kunden SET DatumJetzt = '$user_date_now', WochentagJetzt = '$user_weekday_now' WHERE KundenID = '$username'";
    $result = $conn->query($sql_update_dates);

    $sql_fetch_data_from_kunden = "SELECT * FROM Kunden WHERE KundenID = '$username'";
    $result2 = $conn->query($sql_fetch_data_from_kunden);

    // Check if user exists in Punkte table
    $sql_check_data = "SELECT * FROM Punkte WHERE BenutzernameID = ?";
    $stmt_check_data = $conn->prepare($sql_check_data);
    $stmt_check_data->bind_param("s", $username);
    $stmt_check_data->execute();
    $result_check_data = $stmt_check_data->get_result();

    if ($result_check_data->num_rows > 0) {
        // User exists, update their points
        $sql_punkte = "UPDATE Punkte SET Punkte = Punkte + 2 WHERE BenutzernameID = ?";
        $stmt_update_punkte = $conn->prepare($sql_punkte);
        $stmt_update_punkte->bind_param("s", $username);
        $stmt_update_punkte->execute();

        if ($stmt_update_punkte->affected_rows > 0) {
            // Update successful
            echo "Points updated successfully.<br>";
        } else {
            // Update failed
            echo "Failed to update points.<br>";
        }
        $stmt_update_punkte->close();
    } else {
        // User does not exist, insert new record
        $sql_insert_data = "INSERT INTO Punkte (BenutzernameID, Punkte) VALUES (?, 2)";
        $stmt_insert_data = $conn->prepare($sql_insert_data);
        $stmt_insert_data->bind_param("s", $username);
        $stmt_insert_data->execute();

        if ($stmt_insert_data->affected_rows > 0) {
            // Insert successful
            echo "Points record created successfully.<br>";
        } else {
            // Insert failed
            echo "Failed to create points record.<br>";
        }
        $stmt_insert_data->close();
    }

    $stmt_check_data->close();

    if (!$result) {
        exit();
    }

    if ($result2->num_rows > 0) {
        $row = $result2->fetch_assoc();
        $standardPassword = $row["generiertesPW"];
        $userDefinedPassword = isset($row["BenutzerPW"]) ? $row["BenutzerPW"] : null;
        $secret = $row["GoogleOAuth"]; // Should be unique for each user

        if (empty($secret)) {
            exit();
        }

        if (password_verify($pw, $standardPassword)) {
            header("Location: ../HTML/newpassword.html");
            exit();
        } elseif ($userDefinedPassword !== null && password_verify($pw, $userDefinedPassword)) {
            // Proceed with inserting data into the Logs table only if not redirected to newpassword.html
                  
            // Google Authenticator verification
            $ga = new PHPGangsta_GoogleAuthenticator();
            error_log("Secret: " . $secret);
            error_log("2FA Code: " . $code2fa);
            $checkResult = $ga->verifyCode($secret, $code2fa, 1); // 1 = 30 seconds window
            error_log("Verification Result: " . ($checkResult ? 'true' : 'false'));
            if($checkResult){
                if (!headers_sent()) {
                    try {
                        // SQL query to insert data
                        $sqlOnline = "INSERT INTO Logs (Benutzername) VALUES ('$username')";

                        // Execute the query
                        $result4 = $conn->query($sqlOnline);

                        // Check if the insertion was successful
                        if ($result4) {
                            // Redirect the user if the insertion was successful
                            header("Location: ../HTML/MyEasyBike.php");
                            exit();
                        } else {
                            // Handle errors
                            error_log("Error in SQL query: " . $conn->error);
                            echo "Error: Unable to insert data. Please try again later.<br>";
                        }
                    } catch (Exception $e) {
                        // Handle MySQL errors or exceptions
                        error_log($e->getMessage());
                    }
                }

            } else {
                // Password does not match, handle accordingly
                echo "Incorrect password or 2FA code. Please try again.<br>";
                // You may want to redirect the user to a login page or display an error message
            }
        } else {
            header("Location: ../HTML/login.html");
        }
    } else {
        // User not found
        exit();
    }

    $conn->close();
} catch (Exception $e) {
    echo "Error creating PHPMailer object: " . $e->getMessage() . "<br>";
}
?>
