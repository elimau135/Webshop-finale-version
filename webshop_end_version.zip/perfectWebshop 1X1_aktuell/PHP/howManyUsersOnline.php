<?php 



// Create connection
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Webshop_DB";


$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sqlOnline = "select count(*) as count FROM Logs";
$result = $conn->query($sqlOnline);

if($result ->num_rows > 0){
    $row = $result->fetch_assoc();
    $onlineCount = $row['count'];
}else{
    $onlineCount = 0;
}

echo $onlineCount;

$conn->close();
