// Example starter JavaScript for disabling form submissions if there are invalid fields
(() => {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  const forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }

      form.classList.add('was-validated')
    }, false)
  })
})()

document.addEventListener('DOMContentLoaded', function () {
  // Hole die gespeicherten Artikel aus dem localStorage
  var storedItems = JSON.parse(localStorage.getItem('cartItems')) || {};
  var checkoutList = document.getElementById('checkoutList');

  // Iteriere durch die gespeicherten Artikel und füge sie der Checkout-Liste hinzu
  for (var articleId in storedItems) {
    if (storedItems.hasOwnProperty(articleId)) {
      var articleInfo = storedItems[articleId];

      // Erstelle ein Listenelement für jeden Artikel
      var listItem = document.createElement('li');
      listItem.className = 'list-group-item d-flex justify-content-between align-items-center';

      // Artikelname
      var productNameElement = document.createElement('span');
      productNameElement.textContent = articleInfo.name;
      listItem.appendChild(productNameElement);

      // Anzahl
      var quantityElement = document.createElement('span');
      quantityElement.textContent = `Quantity: ${articleInfo.quantity}`;
      listItem.appendChild(quantityElement);

      // Preis (hier wird der Preis aus dem localStorage verwendet)
      var totalPriceElement = document.createElement('span');
      var totalPrice = articleInfo.price * articleInfo.quantity;
      totalPriceElement.textContent = `Total: $${totalPrice.toFixed(2)}`;
      listItem.appendChild(totalPriceElement);

      checkoutList.appendChild(listItem);
    }
  }
});

document.getElementById('checkoutForm').addEventListener('change', function (event) {
  if (event.target.type === 'radio' && event.target.name === 'shipping') {
      console.log('Checkbox ausgewählt:', event.target.value);

      var shippingOption = event.target.value;
      var shippingCost = getShippingCost(shippingOption);

      console.log('Versandkosten:', shippingCost);

      var checkoutList = document.getElementById('checkoutList');
      var shippingListItem = document.createElement('li');
      shippingListItem.className = 'list-group-item d-flex justify-content-between align-items-center';

      var shippingOptionElement = document.createElement('span');
      shippingOptionElement.textContent = 'Versand: ' + shippingOption;
      shippingListItem.appendChild(shippingOptionElement);

      var shippingCostElement = document.createElement('span');
      shippingCostElement.textContent = 'Kosten: €' + shippingCost.toFixed(2);
      shippingListItem.appendChild(shippingCostElement);

      var existingShippingInfo = document.querySelector('#checkoutList li:last-child');
      if (existingShippingInfo && existingShippingInfo.textContent.includes('Versand:')) {
          console.log('Letztes Element entfernt:', existingShippingInfo);
          checkoutList.removeChild(existingShippingInfo);
      }

      checkoutList.appendChild(shippingListItem);
  }
});

function getShippingCost(option) {
  switch (option) {
      case 'standard':
          return 5;
      case 'express':
          return 10;
      case 'overnight':
          return 20;
      default:
          return 0;
  }
}