<?php 
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Rest of your code
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Webshop_DB";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$user_id = $_SESSION['user_id'];

if ($user_id) {
  $user_id = $_SESSION['user_id'];
} else {
  header('Location: ../index.html');
  exit();
}

$shoppingcart_number_for_sql = $_SESSION['warenkorbid_to_reorder'];
echo $shoppingcart_number_for_sql;
echo $user_id;


$sql_user_information = "
SELECT Vorname, Nachname
FROM Kunden
WHERE KundenID= '$user_id'
";
$result_user_info= $conn->query($sql_user_information);


$row_user_info = $result_user_info->fetch_assoc();

$firstname = $row_user_info["Vorname"];
$lastname = $row_user_info["Nachname"];


$sql_insert_into_warenkorbkopf = "INSERT INTO warenkorbkopf (username_fk, datumDerErstellung, status) VALUES ('$user_id', NOW(), 'in Auftrag')";
$result_insert_warenkorbkopf = $conn->query($sql_insert_into_warenkorbkopf);

$sql_max_warenkorbid = "SELECT MAX(warenkorb_id) AS max_warenkorb_id FROM warenkorbkopf";
$result = $conn->query($sql_max_warenkorbid);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $kopf_id= $row['max_warenkorb_id'];
} else {
    // Handle case where no rows are returned
    $kopf_id = null;
}

$sql_insert_into_warenkorbpos = "INSERT INTO warenkorbposition (warenkorbkopf_id, produkt_id, menge, preis) SELECT $kopf_id, produkt_id, menge, preis FROM warenkorbposition WHERE warenkorbkopf_id = $shoppingcart_number_for_sql";
$result_insert_warenkorbpos = $conn->query($sql_insert_into_warenkorbpos);



$sql_insert_into_rechnungskopf = "INSERT INTO rechnungskopf (kunden_id, rechnungskopf_date, summe, versandart, bezahlungsart, kundenVorname, kundenNachname, kundenBundesstaat, zipcode, username, strasse, stadt) 
                                  SELECT $kopf_id, rechnungskopf_date, summe, versandart, bezahlungsart, kundenVorname, kundenNachname, kundenBundesstaat, zipcode, username, strasse, stadt 
                                  FROM rechnungskopf 
                                  WHERE kunden_id = '$shoppingcart_number_for_sql'";
$result_insert_rechnungskopf = $conn->query($sql_insert_into_rechnungskopf);



 $sql_insert_into_rechnungspos = "INSERT INTO rechnungsposition (rechnungskopf_id, produkt_id,menge, preis) SELECT $kopf_id, produkt_id, menge, preis FROM rechnungsposition WHERE rechnungskopf_id = $shoppingcart_number_for_sql";
    $result_insert_rechnungspos = $conn->query($sql_insert_into_rechnungspos);

$sql_update_punkte = "update punkte set punkte = punkte + 25 where benutzernameid = '$user_id'";
$result = $conn->query($sql_update_punkte);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dankes-Seite</title>
    <link rel="stylesheet" href="../bootstrap stuff/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../CSS/shophelm1.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</head>
<body>
<header>
        <nav class="navbar navbar-dark bg-dark fixed-top bg-transparent">
            <div class="container-fluid">
              <a class="navbar-brand" href="../PHP/logout.php" style="color: rgb(255, 0, 0);"><b><button class=" btn btn-bd-primary-2 btn-lg">easybike.</button></b></a>
            
                <div class="offcanvas-body">
                  <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                    
                    
                  </ul> 
                </div>
              </div>
            </div>
          </nav>
    </header>
   
    <section>
      <div class="container text-center" style="margin-top: 250px;">
            <div class="card" style="width: 100%; height: 100%;">
              <div class="card-body">
                <h6 style="color: rgb(165, 165, 165);">Vielen Dank fuer deinen Einkauf</h6>
                <br>
                <p class="card-text"> Das ganze MyEasyBike-Team wuenscht dir ganz viel Spass mit deinen neuen Artikeln<br>
                     <br>
              </div>
              
              
            </div>
      </section>
      
    
    
</body>
</html>

<?php 

try{
        $user_name = $_SESSION['user_id'];

        $mail = new PHPMailer(true);
        // Server settings
        try{
            $mail->isSMTP(); // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com'; // Specify main and backup SMTP servers
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = 't35tm41l3l145@gmail.com'; // SMTP username
            $mail->Password = 'kerx vbpv xccr rbit'; // SMTP password
            $mail->SMTPSecure = 'tls'; // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587; // TCP port to connect to   
    
            //Email content
    
            $mail->setFrom('t35tm41l3l145@gmail.com', 'Elias Maurer');
            $mail->addAddress($user_name, $firstname . '' . $lastname);

    
            ob_start(); // Start output buffering
            require '../HTML/emails/reorderReviewEmail.php'; // Include PHP script
            $htmlContent = ob_get_clean();

            // Content
            $mail->isHTML(true);                                   // Set email format to HTML
            $mail->Subject = 'Bestelluebersicht '.  $user_name;

            $mail->AddEmbeddedImage('../Images/logo.png', 'logo_2u');
            
            $mail->Body = $htmlContent;  
            
            $mail->send();
            echo 'Message has been sent';
            // header("Location: ../HTML/registrierungsBestaetigung.html");
            exit();
        }catch(Exception $e){
            echo "Error creating PHPMailer object: " . $e->getMessage();
        }
            
    

}catch (Exception $e) {
    echo "Error creating PHPMailer object: " . $e->getMessage();
}
