<?PHP
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Webshop_DB";
$conn = new mysqli($servername, $username, $password, $dbname);

$userid_from_session = $_SESSION["user_id"];

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$shoppingcart_number_for_sql = $_SESSION['warenkorbid_to_reorder'];

$sql_get_items_from_shopping_cart = "
SELECT wp.*, p.*
FROM warenkorbposition wp
JOIN produkte p ON wp.produkt_id = p.ProduktID
WHERE wp.warenkorbkopf_id = '$shoppingcart_number_for_sql'
";
$result_items_from_shopping_cart = $conn->query($sql_get_items_from_shopping_cart);

$sql_get_lieferadresse = "SELECT * FROM rechnungskopf WHERE username='$userid_from_session' and kunden_id='$shoppingcart_number_for_sql'";
$result_for_lieferadresse = $conn->query($sql_get_lieferadresse);

$row_lieferadresse = $result_for_lieferadresse->fetch_assoc();

$bestellnummer = $shoppingcart_number_for_sql;
$bestelldatum = $row_lieferadresse["rechnungskopf_date"];
$firstname = $row_lieferadresse["kundenVorname"];
$lastname = $row_lieferadresse["kundenNachname"];
$strassenName = $row_lieferadresse["strasse"];
$zip_code = $row_lieferadresse["zipcode"];
$city_name = $row_lieferadresse["stadt"];

?>
<!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Order-Review</title>
      <link rel="stylesheet" href="../bootstrap stuff/css/bootstrap.min.css">
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
      <link rel="stylesheet" href="../CSS/shophelm1.css">
      <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
      <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
      <style>
        #section_top{
          width: 47em;
    height: 5em;
    background-color: lightblue;
    margin-left: 10px;
    margin-right: 10px;

        }

        table {
  border-collapse: collapse;
}
tr { 
  border: solid;
  border-width: 1px 0;
}

td {
    padding: 0 15px;
  }

  #text_align_right{
    text-align: right;
  }
      </style>
  
    </head>
  <body>

  <section id="section_top" class="row">
    <table style="width: 47em;">
        <tr>
          <td>
            <p id="text_align_left"><img src="cid:logo_2u" width="100" height="50" /></p>
          </td>
        <td>
          <p id="text_align_right"><b>Bestelldatum:</b> <?php echo $bestelldatum; ?></p>
          <p id="text_align_right"><b>Bestellnummer:</b> <?php echo $bestellnummer; ?> </p>
        </td>
        </tr>
  </table>
</section>



    <section>
    <p id="text_align_left"><b>Lieferadresse</b></p>
    <p id="text_align_left"><?php echo $firstname;?> <?php echo $lastname;?> </p>
    <p id="text_align_left"><?php echo $strassenName;?></p>
    <p id="text_align_left"><?php echo $zip_code;?> <?php echo $city_name;?></p>
    <p id="text_align_left">Deutschland</p>
  </section>
  <p></p>
  <p></p>
  <section>
    <p id="text_align_left"><b>Rechnungsadresse</b></p>
    <p id="text_align_left"><?php echo $firstname;?> <?php echo $lastname;?> </p>
    <p id="text_align_left"><?php echo $strassenName;?></p>
    <p id="text_align_left"><?php echo $zip_code;?> <?php echo $city_name;?></p>
    <p id="text_align_left">Deutschland</p>
  </section>
      <section>
        <div class="container text-center" style="margin-top: 100px;">
              <div class="card" style="width: 100%; height: 100%;">
                <div class="card-body">
                  <h1>Bestelluebersicht</h1>
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>Artikel ID</th>
                        <th>Artikel Name</th>
                        <th>Artikel Beschreibung</th>
                        <th>Artikelmenge</th>
                        <th>Artikelpreis</th>
                        <th>Bestellnummer</th>
                        <th>Einzelpreis</th>
                        <th>Summe</th>
                    </tr>
                    </thead>
                    <tbody>



                      <?php


$total_sum = 0;
if ($result_items_from_shopping_cart->num_rows > 0) {
  while ($row = $result_items_from_shopping_cart->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($row["produkt_id"]) . "</td>";
    echo "<td>" . htmlspecialchars($row["ProduktName"]) . "</td>";
    echo "<td>" . htmlspecialchars($row["Beschreibung"]) . "</td>";
    echo "<td>" . htmlspecialchars($row["menge"]) . "</td>";
    echo "<td>" . htmlspecialchars($row["preis"]) . "</td>";
    echo "<td>" . htmlspecialchars($row["warenkorbkopf_id"]) . "</td>";
    if (intval($row["menge"]) >= 10) {
      $discounted_val_20_percent = floatval($row["preis"]) * 0.8;
      echo "<td>" . $discounted_val_20_percent . "</td>";
      $val_for_price_sum = $discounted_val_20_percent * intval($row["menge"]);
      echo "<td>" . $val_for_price_sum . "</td>";
    } elseif (intval($row["menge"]) >= 5) {
      $discounted_val_10_percent = floatval($row["preis"]) * 0.9;
      echo "<td>" . $discounted_val_10_percent . "</td>";
      $val_for_price_sum = $discounted_val_10_percent * intval($row["menge"]);
      echo "<td>" . $val_for_price_sum . "</td>"; 
    } else {
      echo "<td>" . $row["preis"] . "</td>";
      $val_for_price_sum = floatval($row["preis"]) * intval($row["menge"]);
      echo "<td>" . $val_for_price_sum . "</td>";  
    }
    echo "</tr>";
    $total_sum += $val_for_price_sum;
  }
}


$sql_shipping_method = "SELECT versandart FROM rechnungskopf WHERE username='$userid_from_session' and kunden_id='$shoppingcart_number_for_sql'";
$result_query_shipping_method = $conn->query($sql_shipping_method);

$row_shipping_method = $result_query_shipping_method->fetch_assoc();
$shippingMethod = $row_shipping_method["versandart"];


if($shippingMethod==="standard"){
  $kosten_fuer_versand = floatval(3.99) ;
}elseif($shippingMethod==="express"){
  $kosten_fuer_versand = floatval(8.99) ;
}else{
  $kosten_fuer_versand = floatval(14.00) ;
}

$total_cost = $total_sum + $kosten_fuer_versand;


echo "<tr>";
echo "<td>Versandart</td>";
echo "<td></td>";
echo "<td></td>";
echo "<td></td>";
echo "<td></td>";
echo "<td></td>";
echo "<td></td>";
if($shippingMethod==="standard"){
  echo "<td>DPD (3.99 &euro;)  </td>";
}elseif($shippingMethod==="express"){
  echo "<td>DHL (8.99€ &euro;)  </td>";
}else{
  echo "<td>DHL (14.00 &euro;)  </td>";
}
echo "</tr>";
echo "<tr>";
echo "<td>Gesammtsumme</td>";
echo "<td></td>";
echo "<td></td>";
echo "<td></td>";
echo "<td></td>";
echo "<td></td>";
echo "<td></td>";
echo "<td>$total_cost" . "&euro; </td>";
echo "</tr>";
?>
</tbody>
  </table>
</div>
</section>



</body>
</html>
