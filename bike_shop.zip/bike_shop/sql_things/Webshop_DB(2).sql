-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 11. Jun 2024 um 16:03
-- Server-Version: 10.4.21-MariaDB
-- PHP-Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `Webshop_DB`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `kunden`
--

CREATE TABLE `kunden` (
  `KundenID` varchar(320) NOT NULL,
  `generiertesPW` varchar(100) DEFAULT NULL,
  `Vorname` text DEFAULT NULL,
  `Nachname` text DEFAULT NULL,
  `DatumVergangen` varchar(100) DEFAULT NULL,
  `WochentagVergangen` varchar(100) DEFAULT NULL,
  `aufloesung` varchar(100) DEFAULT NULL,
  `GoogleOAuth` varchar(100) DEFAULT NULL,
  `DatumJetzt` date DEFAULT NULL,
  `WochentagJetzt` varchar(30) DEFAULT NULL,
  `BenutzerPW` varchar(560) DEFAULT NULL,
  `betriebssystem` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `logs` (
  `Benutzername` varchar(320) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `produkte`
--

CREATE TABLE `produkte` (
  `ProduktID` int(11) NOT NULL,
  `ProduktName` varchar(100) DEFAULT NULL,
  `Preis` decimal(10,2) DEFAULT NULL,
  `Beschreibung` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `produkte`
--
INSERT INTO `produkte` (`ProduktID`, `ProduktName`, `Preis`, `Beschreibung`) VALUES
(551, 'AGV PISTA GP', '1399.99', 'Premium Helm'),
(552, 'easybike PRO+', '700.00', 'Pro Helm, welcher zu deinen Beduerfnissen passt'),
(553, 'Aeasybike F2', '299.99', 'Budget Helm, welcher ideal zu dir zugeschnitten ist'),
(561, 'GP Jacket', '1450.00', 'Premium Jacket, für deine Rennader'),
(562, 'Jacket PRO+', '1000.00', 'Pro Jacket, um dich immer zu schützen'),
(563, 'Jacket Ü4', '700.00', 'Unsere Buget Option, um dich rund um zu schützen'),
(571, 'GP Glove', '450.00', 'Premium Handschuhe, für deine Rennsport Gelüste'),
(572, 'Glove PRO+', '250.50', 'Pro Handschuhe'),
(573, 'Glove p3', '99.99', 'Budget Handschuhe');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `punkte`
--

CREATE TABLE `punkte` (
  `BenutzernameID` varchar(320) NOT NULL,
  `punkte` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `punkte`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `rechnungskopf`
--

CREATE TABLE `rechnungskopf` (
  `rechnungskopf_id` int(11) NOT NULL,
  `kunden_id` varchar(50) NOT NULL,
  `rechnungskopf_date` date DEFAULT NULL,
  `summe` decimal(10,2) DEFAULT NULL,
  `versandart` varchar(50) DEFAULT NULL,
  `bezahlungsart` varchar(50) DEFAULT NULL,
  `kundenVorname` varchar(255) DEFAULT NULL,
  `kundenNachname` varchar(255) DEFAULT NULL,
  `kundenBundesstaat` varchar(30) DEFAULT NULL,
  `zipcode` varchar(10) DEFAULT NULL,
  `username` varchar(60) DEFAULT NULL,
  `strasse` varchar(100) DEFAULT NULL,
  `stadt` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `rechnungskopf`
--

--
-- Tabellenstruktur für Tabelle `rechnungsposition`
--

CREATE TABLE `rechnungsposition` (
  `line_item_id` int(11) NOT NULL,
  `rechnungskopf_id` int(11) NOT NULL,
  `produkt_id` int(11) NOT NULL,
  `menge` int(11) DEFAULT NULL,
  `preis` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `rechnungsposition`
--

--
-- Tabellenstruktur für Tabelle `testtable`
--

--
-- Daten für Tabelle `testtable`
--

CREATE TABLE `warenkorbkopf` (
  `warenkorb_id` int(11) NOT NULL,
  `username_fk` varchar(320) DEFAULT NULL,
  `datumDerErstellung` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--

--
-- Tabellenstruktur für Tabelle `warenkorbposition`
--

CREATE TABLE `warenkorbposition` (
  `warenkorbposition_id` int(11) NOT NULL,
  `warenkorbkopf_id` int(11) NOT NULL,
  `produkt_id` int(11) NOT NULL,
  `menge` int(11) DEFAULT NULL,
  `preis` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `warenkorbposition`
--

--
-- Indizes für die Tabelle `kunden`
--
ALTER TABLE `kunden`
  ADD PRIMARY KEY (`KundenID`);

--
-- Indizes für die Tabelle `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`Benutzername`);

--
-- Indizes für die Tabelle `produkte`
--
ALTER TABLE `produkte`
  ADD PRIMARY KEY (`ProduktID`);

--
-- Indizes für die Tabelle `punkte`
--
ALTER TABLE `punkte`
  ADD PRIMARY KEY (`BenutzernameID`);

--
-- Indizes für die Tabelle `rechnungskopf`
--
ALTER TABLE `rechnungskopf`
  ADD PRIMARY KEY (`rechnungskopf_id`);

--
-- Indizes für die Tabelle `rechnungsposition`
--
ALTER TABLE `rechnungsposition`
  ADD PRIMARY KEY (`line_item_id`);

--
-- Indizes für die Tabelle `testtable`
--
ALTER TABLE `testtable`
  ADD PRIMARY KEY (`warenkorbposition_id`);

--
-- Indizes für die Tabelle `warenkorbkopf`
--
ALTER TABLE `warenkorbkopf`
  ADD PRIMARY KEY (`warenkorb_id`);

--
-- Indizes für die Tabelle `warenkorbposition`
--
ALTER TABLE `warenkorbposition`
  ADD PRIMARY KEY (`warenkorbposition_id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `rechnungskopf`
--
ALTER TABLE `rechnungskopf`
  MODIFY `rechnungskopf_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT für Tabelle `rechnungsposition`
--
ALTER TABLE `rechnungsposition`
  MODIFY `line_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=245;

--
-- AUTO_INCREMENT für Tabelle `testtable`
--
ALTER TABLE `testtable`
  MODIFY `warenkorbposition_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT für Tabelle `warenkorbkopf`
--
ALTER TABLE `warenkorbkopf`
  MODIFY `warenkorb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT für Tabelle `warenkorbposition`
--
ALTER TABLE `warenkorbposition`
  MODIFY `warenkorbposition_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
