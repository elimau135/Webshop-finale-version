
<?php 
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);


// Rest of your code
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php';
try{
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "Webshop_DB";
        $conn = new mysqli($servername, $username, $password, $dbname);


        $password_string = 'abcdefghijklmnpqrstuwxyzABCDEFGHJKLMNPQRSTUWXYZ23456789';
        $pw = substr(str_shuffle($password_string), 0, 6);


        $hashedPassword = password_hash($pw, PASSWORD_DEFAULT);
        
        // Sample data to be inserted
        $user_name = $_POST["user_mail"];

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "UPDATE Kunden SET generiertesPW = '$hashedPassword', BenutzerPW =' ' WHERE KundenID = '$user_name'";
        // Execute the update query
        if ($conn->query($sql) === TRUE) {
          echo "Data updated successfully<br>";
        } else {
          echo "Error updating data: " . $conn->error . "<br>";
        }

        if (isset($conn)){
            $conn->close();
        }
        //gut35pw_v0n_3L145.M
    
        $mail = new PHPMailer(true);
        // Server settings
        try{
            $mail->isSMTP(); // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com'; // Specify main and backup SMTP servers
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = 't35tm41l3l145@gmail.com'; // SMTP username
            $mail->Password = 'kerx vbpv xccr rbit'; // SMTP password
            $mail->SMTPSecure = 'tls'; // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587; // TCP port to connect to   
    
            //Email content
    
            $mail->setFrom('t35tm41l3l145@gmail.com', 'Elias Maurer');
            $mail->addAddress($user_name,'Elias Maurer');
    
            // Content
            $mail->isHTML(true);                                   // Set email format to HTML
            $mail->Subject = 'HTML Email Example';
            
            $htmlContent = file_get_contents('../HTML/emails/password_reset_mail.php');
            $htmlContent = str_replace('$pw', $pw, $htmlContent); // Replace $pw with the actual password
            $htmlContent = str_replace('$secret', $secret, $htmlContent); // Replace $secret with the actual secret
            
            $mail->Body = $htmlContent;  
            
            $_SESSION['$pw_standard_registration'] = $pw;
            // Send the email
            $mail->send();
            echo 'Message has been sent';
            header("Location: ../HTML/login.html");
            exit();
        }catch(Exception $e){
            echo "Error creating PHPMailer object: " . $e->getMessage();
        }
            
    

}catch (Exception $e) {
    echo "Error creating PHPMailer object: " . $e->getMessage();
}
