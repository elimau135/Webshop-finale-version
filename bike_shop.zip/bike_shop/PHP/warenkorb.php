<?php 
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

try{
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "Webshop_DB";
        $conn = new mysqli($servername, $username, $password, $dbname);


        $artikelpreis551_von_warenkorb = $_POST["artikelname551"];
        $artikelmenge551_von_warenkorb = $_POST["artikelmenge551"];
        $artikelpreis551_von_warenkorb = $_POST["artikelpreis551"];
        $artikelartikelid551_von_warenkorb = $_POST["artikelartikelid551"];
        
        $artikelpreis552_von_warenkorb = $_POST["artikelname552"];
        $artikelmenge552_von_warenkorb = $_POST["artikelmenge552"];
        $artikelpreis552_von_warenkorb = $_POST["artikelpreis552"];
        $artikelartikelid552_von_warenkorb = $_POST["artikelartikelid552"];
        
        $artikelpreis553_von_warenkorb = $_POST["artikelname553"];
        $artikelmenge553_von_warenkorb = $_POST["artikelmenge553"];
        $artikelpreis553_von_warenkorb = $_POST["artikelpreis553"];
        $artikelartikelid553_von_warenkorb = $_POST["artikelartikelid553"];
        
        $artikelpreis561_von_warenkorb = $_POST["artikelname561"];
        $artikelmenge561_von_warenkorb = $_POST["artikelmenge561"];
        $artikelpreis561_von_warenkorb = $_POST["artikelpreis561"];
        $artikelartikelid561_von_warenkorb = $_POST["artikelartikelid561"];
        
        $artikelpreis562_von_warenkorb = $_POST["artikelname562"];
        $artikelmenge562_von_warenkorb = $_POST["artikelmenge562"];
        $artikelpreis562_von_warenkorb = $_POST["artikelpreis562"];
        $artikelartikelid562_von_warenkorb = $_POST["artikelartikelid562"];
        
        $artikelpreis563_von_warenkorb = $_POST["artikelname563"];
        $artikelmenge563_von_warenkorb = $_POST["artikelmenge563"];
        $artikelpreis563_von_warenkorb = $_POST["artikelpreis563"];
        $artikelartikelid563_von_warenkorb = $_POST["artikelartikelid563"];

        $artikelpreis571_von_warenkorb = $_POST["artikelname571"];
        $artikelmenge571_von_warenkorb = $_POST["artikelmenge571"];
        $artikelpreis571_von_warenkorb = $_POST["artikelpreis571"];
        $artikelartikelid571_von_warenkorb = $_POST["artikelartikelid571"];
        
        $artikelpreis572_von_warenkorb = $_POST["artikelname572"];
        $artikelmenge572_von_warenkorb = $_POST["artikelmenge572"];
        $artikelpreis572_von_warenkorb = $_POST["artikelpreis572"];
        $artikelartikelid572_von_warenkorb = $_POST["artikelartikelid572"];
        
        $artikelpreis573_von_warenkorb = $_POST["artikelname573"];
        $artikelmenge573_von_warenkorb = $_POST["artikelmenge573"];
        $artikelpreis573_von_warenkorb = $_POST["artikelpreis573"];
        $artikelartikelid573_von_warenkorb = $_POST["artikelartikelid573"];

        
        echo $pageRequester_registration;
 
        require_once 'google_auth/PHPGangsta/GoogleAuthenticator.php';
    
        $ga = new PHPGangsta_GoogleAuthenticator();
    
        $secret = $ga->createSecret(); // Should be unique for each user
    
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
    
        $sql = "INSERT INTO Kunden (KundenID, generiertesPW, Vorname, Nachname, DatumVergangen, WochentagVergangen, Aufloesung, betriebssystem, GoogleOAuth, DatumJetzt, WochentagJetzt, BenutzerPW)
        VALUES ('$user_name', '$pw', '$firstname', '$lastname', '$user_date_now', '$user_weekday_now', '$screen_resolution', '$os', '$secret', NULL, NULL, NULL )";
    
        if ($conn->query($sql) === TRUE) {
            echo "Data inserted successfully";
        }else {
    
            if($conn->errno == 1062){
                header("Location:../index.html");
                exit();
            }else{
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            
        }
        if (isset($conn)){
            $conn->close();
        }
        //gut35pw_v0n_3L145.M
    
        $mail = new PHPMailer(true);
        // Server settings
        try{
            $mail->isSMTP(); // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com'; // Specify main and backup SMTP servers
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = 't35tm41l3l145@gmail.com'; // SMTP username
            $mail->Password = 'kerx vbpv xccr rbit'; // SMTP password
            $mail->SMTPSecure = 'tls'; // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587; // TCP port to connect to   
    
            //Email content
    
            $mail->setFrom('t35tm41l3l145@gmail.com', 'Elias Maurer');
            $mail->addAddress($user_name,'Elias Maurer');
    
            // Content
            $mail->isHTML(true);                                   // Set email format to HTML
            $mail->Subject = 'HTML Email Example';
            
            $htmlContent = file_get_contents('../HTML/emails/registrierungsmaildesign.php');
            $htmlContent = str_replace('$pw', $pw, $htmlContent); // Replace $pw with the actual password
            $htmlContent = str_replace('$secret', $secret, $htmlContent); // Replace $secret with the actual secret
            
            $mail->Body = $htmlContent;  
            
            $_SESSION['$pw_standard_registration'] = $pw;
            $_SESSION['$secret_registration'] = $secret;
    
            
            // Send the email
            $mail->send();
            echo 'Message has been sent';
            header("Location: ../HTML/registrierungsBestaetigung.html");
            exit();
        }catch(Exception $e){
            echo "Error creating PHPMailer object: " . $e->getMessage();
        }
            
    

}catch (Exception $e) {
    echo "Error creating PHPMailer object: " . $e->getMessage();
}
