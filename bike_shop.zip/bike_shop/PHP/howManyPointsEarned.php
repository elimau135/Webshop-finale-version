
<?php
session_start(); // Ensure session is started

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Webshop_DB";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id']; // Corrected variable name to match the session variable

$sqlPointsEarned = "SELECT punkte FROM punkte WHERE BenutzernameID = '$user_id'";
$result = $conn->query($sqlPointsEarned);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $pointsEarned = $row['punkte'];
} else {
    $pointsEarned = 0;
}

echo $pointsEarned;

$conn->close();
?>

