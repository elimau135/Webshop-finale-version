<?php 
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);


// Rest of your code
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php';
try{
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "Webshop_DB";
        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
    
    
        $mail = new PHPMailer(true);
        // Server settings
        try{
            $mail->isSMTP(); // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com'; // Specify main and backup SMTP servers
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = 't35tm41l3l145@gmail.com'; // SMTP username
            $mail->Password = 'kerx vbpv xccr rbit'; // SMTP password
            $mail->SMTPSecure = 'tls'; // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587; // TCP port to connect to   
    
            $mail->setFrom('t35tm41l3l145@gmail.com', 'Elias Maurer');
            $mail->addAddress($user_name,'Elias Maurer');
    
            $mail->isHTML(true);                                   // Set email format to HTML
            $mail->Subject = 'Ihre Bestellübersicht' ;
            
            $htmlContent = file_get_contents('../HTML/emails/orderReviewEmail.php');
            $mail->Body = $htmlContent;  

            $mail->AddEmbeddedImage('../Images/Glove1.jpg', 'logo_2u');
            
            $mail->send();
            echo 'Message has been sent';
            header("Location: ../HTML/registrierungsBestaetigung.html");
            exit();
        }catch(Exception $e){
            echo "Error creating PHPMailer object: " . $e->getMessage();
        }
            
    

}catch (Exception $e) {
    echo "Error creating PHPMailer object: " . $e->getMessage();
}
