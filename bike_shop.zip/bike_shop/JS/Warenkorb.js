var cartArray = []


function send_data_to_php(){
    let cart_array_to_json = JSON.stringify(cartArray)
    console.log(cart_array_to_json);
    document.getElementById("jsonstring_for_php").value = cart_array_to_json;

    
}


document.addEventListener('DOMContentLoaded', () => {
    // Retrieve data for items
    var items = [551, 552, 553, 561, 562, 563, 571, 572, 573];
    items.forEach(itemId => {
        retrieveItemData(itemId);
    });
});

function retrieveItemData(itemId) {
    const name = document.getElementById(`artikelname${itemId}`)?.textContent;
    const menge = document.getElementById(`artikelmenge${itemId}`)?.textContent;
    const preis = document.getElementById(`artikelpreis${itemId}`)?.textContent;
    const id = document.getElementById(`artikelid${itemId}`)?.textContent;
    // Use retrieved data as needed
}

function showSidebar(){
    toggleSidebar('0');
    updateCartCount();
}

function hideSidebar() {
    toggleSidebar('-450px');
}

function toggleSidebar(position) {
    const sidebar = document.getElementById("sidebar");
    sidebar.style.right = position;
}

function checkout() {
    if (cartItems.length === 0) {
        alert("Der Warenkorb ist leer. Bitte fügen Sie Artikel hinzu, um fortzufahren.");
        return;
    }


    // Proceed to checkout
}

function addToCart(itemId, itemName, itemPrice, itemNumber, availableQuantity) {
    const quantityInput = document.getElementById(`quantity${itemId}`);
    const quantity = parseInt(quantityInput.value);

    if (quantity > availableQuantity) {
        alert("Die gewählte Menge übersteigt die verfügbare Stückzahl.");
        return;
    }

    const imageUrl = document.getElementById(`item${itemId}`).querySelector("img").src;
    let cartItem = findCartItemByNumber(itemNumber);

    if (cartItem) {
        cartItem.quantity += quantity;
        updateCartItemQuantity(cartItem);
    } else {
        cartItem = {
            itemName,
            quantity,
            price: itemPrice,
            number: itemNumber,
            imageUrl,
            discount: calculateDiscount(quantity)
        };
        cartArray.push(cartItem);
        addCartItemToSidebar(cartItem);
        console.log(cartArray);
    }

    availableQuantity -= quantity;
    updateAvailableQuantityOnPage(itemId, availableQuantity);
    updateCartCount();
    updateTotalPrice();
}

function findCartItemByNumber(itemNumber) {
    const cartItems = document.querySelectorAll(".cartItem");

    for (const cartItem of cartItems) {
        const cartItemNumber = cartItem.querySelector("p:nth-child(3)").innerText.replace("Artikelnummer: ", "").trim();

        if (cartItemNumber === itemNumber.trim()) {
            return {
                element: cartItem,
                quantity: parseInt(cartItem.querySelector("p:nth-child(5) span").innerText)
            };
        }
    }
    return null;
}

function addCartItemToSidebar(cartItem) {
    const cartItemsList = document.getElementById("cartItems");
    const cartItemElement = document.createElement("li");
    cartItemElement.className = "cartItem";
    cartItemElement.dataset.discount = cartItem.discount;

    cartItemElement.innerHTML = `
        <img src="${cartItem.imageUrl}" alt="${cartItem.itemName}">
        <p>${cartItem.itemName}</p>
        <p>Artikelnummer: ${cartItem.number}</p>
        <p>Preis: $${cartItem.price.toFixed(2)}</p>
        <p>Menge: <span>${cartItem.quantity}</span></p>
        <button onclick="removeCartItem(this)">Entfernen</button>
        <button onclick="updateQuantity(this, -1, ${cartItem.price}, ${JSON.stringify(cartItem).replace(/"/g, "&quot;")})">-</button>
        <button onclick="updateQuantity(this, 1, ${cartItem.price}, ${JSON.stringify(cartItem).replace(/"/g, "&quot;")})">+</button>
    `;

    cartItemsList.appendChild(cartItemElement);
    showSidebar();
    updateCartDiscountAndTotalPrice();

    updateItemDisplay(cartItem);
}

function updateQuantity(button, change, price, cartItem) {
    const listItem = button.parentNode;
    const quantityElement = listItem.querySelector("p:nth-child(5) span");
    const currentQuantity = parseInt(quantityElement.innerText);
    const newQuantity = currentQuantity + change;

    if (newQuantity >= 0) {
        quantityElement.innerText = newQuantity;

        if (newQuantity === 0) {
            removeCartItem(button);
        } else {
            console.log(cartArray);
            const cartItemIndex = cartArray.findIndex(item => item.number === cartItem.number)

            if (cartItemIndex !== -1) {
                cartArray[cartItemIndex].quantity = newQuantity;
                console.log(cartArray);
            }
            updateCartItemDiscount(listItem);
            updateTotalPrice();
            updateCartCount();
        }
    }
    updateItemDisplay(cartItem, newQuantity);
}

function updateTotalPrice() {
    const cartItems = document.querySelectorAll(".cartItem");
    let totalPrice = 0;

    cartItems.forEach(item => {
        const price = parseFloat(item.querySelector("p:nth-child(4)").innerText.replace("Preis: $", ""));
        const quantity = parseInt(item.querySelector("span").innerText);
        const discount = parseFloat(item.dataset.discount || "0");

        totalPrice += (price * quantity) * (1 - discount);
    });

    document.getElementById("totalPrice").innerText = "Gesamtpreis: $" + totalPrice.toFixed(2);
}

function updateCartItemQuantity(cartItem) {
    cartItem.element.querySelector("span").innerText = cartItem.quantity;
    updateTotalPrice();
    updateCartCount();
}

function removeCartItem(button) {
    const listItem = button.parentNode;
    const itemNumber = listItem.querySelector("p:nth-child(3)").innerText.replace("Artikelnummer: ", "").trim();
    const cartItem = findCartItemByNumber(itemNumber);

    if (cartItem) {
        listItem.remove();
        updateTotalPrice();
        updateCartCount();
    }

    const cartItemIndex = cartArray.findIndex(item => item.number === cartItem.number)

    cartArray.splice(cartItemIndex, 1)
    console.log(cartArray);
}

function updateCartCount() {
    const cartItems = document.querySelectorAll("#cartItems .cartItem p:nth-child(5) span");
    let totalCount = 0;

    cartItems.forEach(quantityElement => {
        totalCount += parseInt(quantityElement.innerText);
    });

    document.getElementById("cartCount").innerText = totalCount;
}
   document.getElementById(`artikelname${cartItem.number}`).innerText = cartItem.itemName;

function updateAvailableQuantityOnPage(itemId, availableQuantity) {
    const list_quantity_vals = [1,2,3,4,5,6,7,8,9]
    var index = items.indexOf(itemId);
    console.log(index)
    console.log(list_quantity_vals)
    if (index !== -1) {
    // If itemId is found in items array
    var quantityValue = list_quantity_vals[index];
    const availableQuantityElement = document.getElementById(`qty${quantityValue}`);
   console.log(availableQuantityElement
    ) 
    // Assuming availableQuantityElement is an input element
    availableQuantityElement.value = quantityValue;
    } else {
      // If itemId is not found in items array
      console.log("Item not found.");
    }
}

function calculateDiscount(quantity) {
    if (quantity >= 10) return 0.2; // 20% discount for 10 or more items
    if (quantity >= 5) return 0.1; // 10% discount for 5 or more items
    return 0; // No discount
}

function updateCartItemDiscount(cartItemElement) {
    const quantity = parseInt(cartItemElement.querySelector("p:nth-child(5) span").innerText);
    const discount = calculateDiscount(quantity);

    cartItemElement.dataset.discount = discount;
    updateTotalPrice();
}

function updateCartDiscountAndTotalPrice() {
    const cartItems = document.querySelectorAll(".cartItem");

    cartItems.forEach(item => {
        const quantity = parseInt(item.querySelector("p:nth-child(5) span").innerText);
        item.dataset.discount = calculateDiscount(quantity);
    });

    updateTotalPrice();
}

function updateItemDisplay(cartItem, newQuantity = cartItem.quantity) {
    document.getElementById(`artikelname${cartItem.number}`).innerText = cartItem.itemName;
    document.getElementById(`artikelmenge${cartItem.number}`).innerText = newQuantity;
    document.getElementById(`artikelpreis${cartItem.number}`).innerText = cartItem.price.toFixed(2);
    document.getElementById(`artikelid${cartItem.number}`).innerText = cartItem.number;
}
