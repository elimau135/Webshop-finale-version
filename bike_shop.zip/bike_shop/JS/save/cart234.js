// Annahme: Hier wird der Warenkorb im Web Storage gespeichert
var cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];

// Funktion zum Aktualisieren des Warenkorb-Inhalts im Web Storage
function updateCartStorage() {
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
}
// Funktion zum Berechnen der Gesamtmenge im Warenkorb
function calculateTotalQuantity() {
    var totalQuantity = cartItems.reduce(function(sum, item) {
        return sum + item.quantity;
    }, 0);
    return totalQuantity;
}

// Funktion zum Aktualisieren der Anzeige der Gesamtmenge im Warenkorb
function updateTotalQuantityDisplay() {
    var totalQuantityElement = document.getElementById('totalQuantity');
    if (totalQuantityElement) {
        totalQuantityElement.textContent = 'Gesamtmenge im Warenkorb: ' + calculateTotalQuantity();
    }
}

function addToCart(quantity) {
    // Hier fügst du die Logik hinzu, um ein Produkt zum Warenkorb hinzuzufügen.
    // Du kannst die Produktdaten (Bild, Name, Anzahl, etc.) in einem Objekt speichern.
    // Beispiel: var product = { image: "produktbild.jpg", name: "Produktname", quantity: 1 };
    // Füge dann dieses Objekt dem Warenkorb hinzu und rufe die Funktion updateCart() auf.

    // Beispiel:
    
    // Beispiel: Füge die eingegebene Menge zum Warenkorb hinzu
    cartItems.push({ quantity: quantity });

    // Aktualisiere den Warenkorb im Web Storage
    updateCartStorage();

    // Aktualisiere die Anzeige der Gesamtmenge im Warenkorb
    updateTotalQuantityDisplay();
}

// Funktion zum Auslösen des Hinzufügens in den Warenkorb bei Klick auf den Button
function handleAddToCartClick() {
    var quantityInput = document.getElementById('quantityInput');
    var quantity = parseInt(quantityInput.value); // Menge aus dem Formularfeld

    if (!isNaN(quantity) && quantity > 0) {
        addToCart(quantity);
        // Hier könntest du weitere Aktionen ausführen, z.B. Feedback für den Benutzer anzeigen
        console.log('Die Menge ' + quantity + ' wurde zum Warenkorb hinzugefügt.');
    } else {
        console.log('Bitte geben Sie eine gültige Menge ein.');
    }
}
// Füge Event-Listener zum "Add to Cart"-Button hinzu
var addToCartButton = document.getElementById('addToCartBtn');
if (addToCartButton) {
    addToCartButton.addEventListener('click', handleAddToCartClick);
}
// Initialisiere die Anzeige der Gesamtmenge im Warenkorb beim Laden der Seite
updateTotalQuantityDisplay();

function addToCartList(product) {
    var cartItems = document.getElementById("cart-items");

    var cartItemDiv = document.createElement("div");
    cartItemDiv.classList.add("cart-item");

    var productImage = document.createElement("img");
    productImage.src = product.image;
    productImage.alt = "Produktbild";
    productImage.classList.add("cart-product-image");

    var productName = document.createElement("span");
    productName.textContent = product.name;

    var quantityInput = document.createElement("input");
    quantityInput.type = "number";
    quantityInput.value = product.quantity;
    quantityInput.min = 1;
    quantityInput.addEventListener("change", function () {
        updateQuantity(product, quantityInput.value);
    });

    var removeBtn = document.createElement("button");
    removeBtn.textContent = '🗑️';
    removeBtn.addEventListener("click", function () {
        removeFromCart(product);
    });

    cartItemDiv.appendChild(productImage);
    cartItemDiv.appendChild(productName);
    cartItemDiv.appendChild(quantityInput);
    cartItemDiv.appendChild(removeBtn);

    cartItems.appendChild(cartItemDiv);

    updateCart();
}

function updateQuantity(product, newQuantity) {
    // Hier fügst du die Logik hinzu, um die Produktmenge im Warenkorb zu aktualisieren.
    // Beispiel: product.quantity = newQuantity;
    // Führe dann die Funktion updateCart() aus.

    // Beispiel:
    product.quantity = newQuantity;
    updateCart();
}

function removeFromCart(product) {
    // Hier fügst du die Logik hinzu, um ein Produkt aus dem Warenkorb zu entfernen.
    // Beispiel: Entferne das Produktobjekt aus dem Warenkorb-Array.
    // Führe dann die Funktion updateCart() aus.

    // Beispiel:
    // cartItems = cartItems.filter(item => item !== product);
    // updateCart();

    var existingRemoveButtons = document.querySelectorAll('.remove-btn');
    existingRemoveButtons.forEach(button => button.remove());

    var removeBtn = document.createElement("div");
    removeBtn.classList.add("remove-btn");
    removeBtn.innerHTML = `
        
    `;
    
    removeBtn.onclick = function() { removeFromCart(product); };

    var cartItemsContainer = document.getElementById("cart-items");
    cartItemsContainer.appendChild(removeBtn);
}

function updateCart() {
    var cartSidebar = document.getElementById("cart-sidebar");
    var cartItems = document.getElementById("cart-items");

    // Hier fügst du die Logik hinzu, um den Gesamtpreis und andere Informationen zu aktualisieren.
    // Beispiel: Iteriere über das Warenkorb-Array und aktualisiere den Inhalt des "cartItems" div.

    // Beispiel:
    // cartItems.innerHTML = "";
    // cartItemsArray.forEach(product => {
    //     addToCartList(product);
    // });

    // Aktualisiere den Gesamtpreis, Gesamtanzahl oder andere Informationen.

    // Animation, um den Warenkorbfenster ein- und auszublenden
    if (cartItems.children.length > 0) {
        cartSidebar.style.right = "0";
    } else {
        cartSidebar.style.right = "-33%";
    }
}

function closeCart() {
    var cartSidebar = document.getElementById("cart-sidebar");
    cartSidebar.style.right = "-33%";
}
function openCart() {
    var cartSidebar = document.getElementById("cart-sidebar");
    cartSidebar.style.right = "0%";
    updateCartItemCount();
}

// Funktion zum Aktualisieren des Warenkorb-Inhalts im DOM
function updateCartContent() {
    var cartItemsList = document.getElementById("cart-items");

    if (cartItemsList) {
        // Leere den Bereich zuerst
        cartItemsList.innerHTML = "";

        // Füge die Artikel im Warenkorb hinzu
        for (var i = 0; i < cartItems.length; i++) {
            var listItem = document.createElement("li");
            listItem.textContent = "Produkt " + (i + 1);  // Hier füge den echten Produktinhalt hinzu
            cartItemsList.appendChild(listItem);
        }
    }
}







