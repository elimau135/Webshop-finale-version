// Lösche den Local Storage beim Laden der Seite, um den vorherigen Einkaufswagen zu entfernen
localStorage.removeItem('cartItems');


function toggleSidebar() {
    var sidebar = document.getElementById('sidebar');
    sidebar.style.width = sidebar.style.width === '0px' ? '450px' : '0';
  }

  function closeSidebar() {
    var sidebar = document.getElementById('sidebar');
    sidebar.style.width = '0';
  }

  function addToSidebar( articleId, articleName, articleImage, articlePrice) {

    

    var quantityInput = document.getElementById('quantity' + articleId);
    var quantity = parseInt(quantityInput.value); 

    // Überprüfe, ob der Artikel bereits in der Sidebar ist
    var existingItem = document.querySelector('.sidebar-item[data-article-id="' + articleId + '"]');
    
    if (existingItem) {
      // Artikel bereits vorhanden, erhöhe die Anzahl
      var existingQuantity = parseInt(existingItem.querySelector('p').textContent.split(':')[1].trim());
      existingItem.querySelector('p').textContent = 'Anzahl: ' + (existingQuantity + quantity);
    } else {
      // Artikel nicht vorhanden, füge ihn hinzu
      // Öffne die Sidebar, wenn ein Artikel zur Sidebar hinzugefügt wird
      toggleSidebar();

      // Erstelle ein neues Sidebar-Element
      var sidebarItem = document.createElement('div');
      sidebarItem.className = 'sidebar-item';
      sidebarItem.setAttribute('data-article-id', articleId);

      // Füge die Informationen zum Artikel in die Sidebar ein
      sidebarItem.innerHTML = `
        <img src="${articleImage}" alt="${articleName}">
        <h3>${articleName}</h3>
        <p>Anzahl: ${quantity}</p>
        <button onclick="removeFromSidebar(this)">Löschen</button>
        <button onclick="increaseQuantity(this)">↑</button>
        <button onclick="decreaseQuantity(this)">↓</button>
      `;

      // Füge das Sidebar-Element zur Sidebar hinzu
      var sidebar = document.getElementById('sidebar');
      sidebar.insertBefore(sidebarItem, sidebar.lastChild.previousSibling); // Einfügen vor der Überschrift und der Trennlinie
    }

        var storedItems = JSON.parse(localStorage.getItem('cartItems')) || {};
        if (storedItems.hasOwnProperty(articleId)) {
        storedItems[articleId].quantity += 1;
        } else {
        storedItems[articleId] = {
        name: articleName,
        quantity: quantity,
        price: articlePrice,
        // ... (andere Eigenschaften des Artikels)
        };
    }
    localStorage.setItem('cartItems', JSON.stringify(storedItems));

    // Benachrichtige über Änderung der Anzahl
    document.dispatchEvent(quantityChangeEvent);
  }

  function removeFromSidebar(button) {
    // Entferne das übergeordnete Element des Buttons (das Sidebar-Element)
    var sidebarItem = button.parentNode;
    sidebarItem.parentNode.removeChild(sidebarItem);

    // Schließe die Sidebar, wenn der letzte Artikel entfernt wurde
    if (document.querySelectorAll('.sidebar-item').length === 0) {
      closeSidebar();
    }
  }

  function increaseQuantity(button) {
    // Ändere die Anzahl im Sidebar-Element
    var quantityElement = button.parentNode.querySelector('p');
    var currentQuantity = parseInt(quantityElement.textContent.split(':')[1].trim());
    quantityElement.textContent = 'Anzahl: ' + (currentQuantity + 1);
  }

  function decreaseQuantity(button) {
    // Ändere die Anzahl im Sidebar-Element, achte darauf, dass sie nicht unter 1 fällt
    var quantityElement = button.parentNode.querySelector('p');
    var currentQuantity = parseInt(quantityElement.textContent.split(':')[1].trim());
    quantityElement.textContent = 'Anzahl: ' + Math.max(currentQuantity - 1, 1);

    // Wenn die Anzahl 1 erreicht, entferne den Artikel aus der Sidebar
    if (currentQuantity === 1) {
      removeFromSidebar(button);
    }
  }


 // Eindeutige IDs für die Artikel
var articleIds = ['article1', 'article2', 'article3', 'article4', 'article5', 'article6', 'article7', 'article8', 'article9'];

// Funktion zum Aktualisieren der Anzeige über dem "Open Cart"-Button
function updateCartBadge() {
  var cartBadge = document.getElementById('cartBadge');
  var totalQuantity = calculateTotalQuantity();

  if (cartBadge) {
    cartBadge.textContent = totalQuantity > 0 ? totalQuantity : '';
  }
}

// Funktion zum Berechnen der Gesamtmenge aller Artikel
function calculateTotalQuantity() {
  var totalQuantity = 0;

  articleIds.forEach(function(articleId) {
    var quantityInput = document.getElementById('quantity' + articleId.charAt(articleId.length - 1));

    if (quantityInput) {
      totalQuantity += parseInt(quantityInput.value) || 0;
    }
  });

  return totalQuantity;
}

// Beispiel für die Aktualisierung der Menge über Pfeiltasten in der Sidebar
articleIds.forEach(function(articleId) {
  var quantityInput = document.getElementById('quantity' + articleId.charAt(articleId.length - 1));

  if (quantityInput) {
    quantityInput.addEventListener('input', function () {
      // Aktualisiere die Anzeige über dem "Open Cart"-Button
      updateCartBadge();
    });
  }
});

// Initialisiere die Anzeige über dem "Open Cart"-Button beim Laden der Seite
updateCartBadge();

