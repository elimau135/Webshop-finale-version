function function_check_password_length() {
    var var_user_password = document.getElementById("pw1").value;
    if (var_user_password.length < 9) {
        console.log("User password is not long enough");
        return false;
    }
    return true;
}

function function_bigletters_ninestrings_number_and_small_letter() {
    var var_user_password = document.getElementById("pw1").value;
    let pattern = new RegExp("^(?=.*[a-z])(?=.*[A-Z]).+$");
    if (pattern.test(var_user_password)) {
        console.log("okay");
        return true;
    } else {
        console.log("User password does not have upper or lower cases or numeric values");
        return false;
    }
}

function function_check_password_are_the_same() {
    var var_user_password = document.getElementById("pw1").value;
    var var_usre_password_validate = document.getElementById("pw2").value;
    if (var_user_password !== var_usre_password_validate) {
        console.log("User passwords do not match");
        return false;
    }
    return true;
}

function send_data() {
    var lengthCheck = function_check_password_length();
    var patternCheck = function_bigletters_ninestrings_number_and_small_letter();
    var matchCheck = function_check_password_are_the_same();
    
    if (!lengthCheck || !patternCheck || !matchCheck) {
        document.getElementById("button_for_new_login").disabled = true;
    } else {
        document.getElementById("button_for_new_login").disabled = false;
    }
}
